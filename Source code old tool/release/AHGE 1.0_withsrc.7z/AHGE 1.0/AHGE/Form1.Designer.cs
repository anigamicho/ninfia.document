﻿namespace Percobaan
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.id_list = new System.Windows.Forms.ComboBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.button6 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.pbx_pl3_2 = new System.Windows.Forms.PictureBox();
            this.pbx_pl3_4 = new System.Windows.Forms.PictureBox();
            this.pbx_pl3_3 = new System.Windows.Forms.PictureBox();
            this.pbx_pl3_1 = new System.Windows.Forms.PictureBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.unk3_6 = new System.Windows.Forms.NumericUpDown();
            this.unk3_5 = new System.Windows.Forms.NumericUpDown();
            this.unk3_4 = new System.Windows.Forms.NumericUpDown();
            this.unk3_3 = new System.Windows.Forms.NumericUpDown();
            this.unk3_2 = new System.Windows.Forms.NumericUpDown();
            this.unk3_1 = new System.Windows.Forms.NumericUpDown();
            this.label9 = new System.Windows.Forms.Label();
            this.fr3_4 = new System.Windows.Forms.NumericUpDown();
            this.fr3_3 = new System.Windows.Forms.NumericUpDown();
            this.fr3_2 = new System.Windows.Forms.NumericUpDown();
            this.fr3_1 = new System.Windows.Forms.NumericUpDown();
            this.mn3_4 = new System.Windows.Forms.NumericUpDown();
            this.mn3_3 = new System.Windows.Forms.NumericUpDown();
            this.mn3_2 = new System.Windows.Forms.NumericUpDown();
            this.mn3_1 = new System.Windows.Forms.NumericUpDown();
            this.label26 = new System.Windows.Forms.Label();
            this.mx3_4 = new System.Windows.Forms.NumericUpDown();
            this.mx3_3 = new System.Windows.Forms.NumericUpDown();
            this.mx3_2 = new System.Windows.Forms.NumericUpDown();
            this.mx3_1 = new System.Windows.Forms.NumericUpDown();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.pl3_4 = new System.Windows.Forms.ComboBox();
            this.pl3_1 = new System.Windows.Forms.ComboBox();
            this.pl3_3 = new System.Windows.Forms.ComboBox();
            this.pl3_2 = new System.Windows.Forms.ComboBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.pbx_pl2_4 = new System.Windows.Forms.PictureBox();
            this.pbx_pl2_3 = new System.Windows.Forms.PictureBox();
            this.pbx_pl2_2 = new System.Windows.Forms.PictureBox();
            this.pbx_pl2_1 = new System.Windows.Forms.PictureBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.unk2_6 = new System.Windows.Forms.NumericUpDown();
            this.unk2_5 = new System.Windows.Forms.NumericUpDown();
            this.unk2_4 = new System.Windows.Forms.NumericUpDown();
            this.unk2_3 = new System.Windows.Forms.NumericUpDown();
            this.unk2_2 = new System.Windows.Forms.NumericUpDown();
            this.unk2_1 = new System.Windows.Forms.NumericUpDown();
            this.label33 = new System.Windows.Forms.Label();
            this.fr2_4 = new System.Windows.Forms.NumericUpDown();
            this.fr2_3 = new System.Windows.Forms.NumericUpDown();
            this.fr2_2 = new System.Windows.Forms.NumericUpDown();
            this.fr2_1 = new System.Windows.Forms.NumericUpDown();
            this.mn2_4 = new System.Windows.Forms.NumericUpDown();
            this.mn2_3 = new System.Windows.Forms.NumericUpDown();
            this.mn2_2 = new System.Windows.Forms.NumericUpDown();
            this.mn2_1 = new System.Windows.Forms.NumericUpDown();
            this.label34 = new System.Windows.Forms.Label();
            this.mx2_4 = new System.Windows.Forms.NumericUpDown();
            this.mx2_3 = new System.Windows.Forms.NumericUpDown();
            this.mx2_2 = new System.Windows.Forms.NumericUpDown();
            this.mx2_1 = new System.Windows.Forms.NumericUpDown();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.pl2_4 = new System.Windows.Forms.ComboBox();
            this.pl2_1 = new System.Windows.Forms.ComboBox();
            this.pl2_3 = new System.Windows.Forms.ComboBox();
            this.pl2_2 = new System.Windows.Forms.ComboBox();
            this.label21 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.pbx_pl1_4 = new System.Windows.Forms.PictureBox();
            this.pbx_pl1_3 = new System.Windows.Forms.PictureBox();
            this.pbx_pl1_2 = new System.Windows.Forms.PictureBox();
            this.pbx_pl1_1 = new System.Windows.Forms.PictureBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.unk1_6 = new System.Windows.Forms.NumericUpDown();
            this.unk1_5 = new System.Windows.Forms.NumericUpDown();
            this.unk1_4 = new System.Windows.Forms.NumericUpDown();
            this.unk1_3 = new System.Windows.Forms.NumericUpDown();
            this.unk1_2 = new System.Windows.Forms.NumericUpDown();
            this.unk1_1 = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.fr1_4 = new System.Windows.Forms.NumericUpDown();
            this.fr1_3 = new System.Windows.Forms.NumericUpDown();
            this.fr1_2 = new System.Windows.Forms.NumericUpDown();
            this.fr1_1 = new System.Windows.Forms.NumericUpDown();
            this.mn1_4 = new System.Windows.Forms.NumericUpDown();
            this.mn1_3 = new System.Windows.Forms.NumericUpDown();
            this.mn1_2 = new System.Windows.Forms.NumericUpDown();
            this.mn1_1 = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.mx1_4 = new System.Windows.Forms.NumericUpDown();
            this.mx1_3 = new System.Windows.Forms.NumericUpDown();
            this.mx1_2 = new System.Windows.Forms.NumericUpDown();
            this.mx1_1 = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pl1_4 = new System.Windows.Forms.ComboBox();
            this.pl1_1 = new System.Windows.Forms.ComboBox();
            this.pl1_3 = new System.Windows.Forms.ComboBox();
            this.pl1_2 = new System.Windows.Forms.ComboBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.button5 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.label57 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.pbx_pl6_4 = new System.Windows.Forms.PictureBox();
            this.pbx_pl6_3 = new System.Windows.Forms.PictureBox();
            this.pbx_pl6_2 = new System.Windows.Forms.PictureBox();
            this.pbx_pl6_1 = new System.Windows.Forms.PictureBox();
            this.label50 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.unk6_6 = new System.Windows.Forms.NumericUpDown();
            this.unk6_5 = new System.Windows.Forms.NumericUpDown();
            this.unk6_4 = new System.Windows.Forms.NumericUpDown();
            this.unk6_3 = new System.Windows.Forms.NumericUpDown();
            this.unk6_2 = new System.Windows.Forms.NumericUpDown();
            this.unk6_1 = new System.Windows.Forms.NumericUpDown();
            this.label52 = new System.Windows.Forms.Label();
            this.fr6_4 = new System.Windows.Forms.NumericUpDown();
            this.fr6_3 = new System.Windows.Forms.NumericUpDown();
            this.fr6_2 = new System.Windows.Forms.NumericUpDown();
            this.fr6_1 = new System.Windows.Forms.NumericUpDown();
            this.mn6_4 = new System.Windows.Forms.NumericUpDown();
            this.mn6_3 = new System.Windows.Forms.NumericUpDown();
            this.mn6_2 = new System.Windows.Forms.NumericUpDown();
            this.mn6_1 = new System.Windows.Forms.NumericUpDown();
            this.label53 = new System.Windows.Forms.Label();
            this.mx6_4 = new System.Windows.Forms.NumericUpDown();
            this.mx6_3 = new System.Windows.Forms.NumericUpDown();
            this.mx6_2 = new System.Windows.Forms.NumericUpDown();
            this.mx6_1 = new System.Windows.Forms.NumericUpDown();
            this.label54 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.pl6_4 = new System.Windows.Forms.ComboBox();
            this.pl6_1 = new System.Windows.Forms.ComboBox();
            this.pl6_3 = new System.Windows.Forms.ComboBox();
            this.pl6_2 = new System.Windows.Forms.ComboBox();
            this.label40 = new System.Windows.Forms.Label();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.pbx_pl5_4 = new System.Windows.Forms.PictureBox();
            this.pbx_pl5_3 = new System.Windows.Forms.PictureBox();
            this.pbx_pl5_2 = new System.Windows.Forms.PictureBox();
            this.pbx_pl5_1 = new System.Windows.Forms.PictureBox();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.unk5_6 = new System.Windows.Forms.NumericUpDown();
            this.unk5_5 = new System.Windows.Forms.NumericUpDown();
            this.unk5_4 = new System.Windows.Forms.NumericUpDown();
            this.unk5_3 = new System.Windows.Forms.NumericUpDown();
            this.unk5_2 = new System.Windows.Forms.NumericUpDown();
            this.unk5_1 = new System.Windows.Forms.NumericUpDown();
            this.label45 = new System.Windows.Forms.Label();
            this.fr5_4 = new System.Windows.Forms.NumericUpDown();
            this.fr5_3 = new System.Windows.Forms.NumericUpDown();
            this.fr5_2 = new System.Windows.Forms.NumericUpDown();
            this.fr5_1 = new System.Windows.Forms.NumericUpDown();
            this.mn5_4 = new System.Windows.Forms.NumericUpDown();
            this.mn5_3 = new System.Windows.Forms.NumericUpDown();
            this.mn5_2 = new System.Windows.Forms.NumericUpDown();
            this.mn5_1 = new System.Windows.Forms.NumericUpDown();
            this.label46 = new System.Windows.Forms.Label();
            this.mx5_4 = new System.Windows.Forms.NumericUpDown();
            this.mx5_3 = new System.Windows.Forms.NumericUpDown();
            this.mx5_2 = new System.Windows.Forms.NumericUpDown();
            this.mx5_1 = new System.Windows.Forms.NumericUpDown();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.pl5_4 = new System.Windows.Forms.ComboBox();
            this.pl5_1 = new System.Windows.Forms.ComboBox();
            this.pl5_3 = new System.Windows.Forms.ComboBox();
            this.pl5_2 = new System.Windows.Forms.ComboBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.pbx_pl4_4 = new System.Windows.Forms.PictureBox();
            this.pbx_pl4_3 = new System.Windows.Forms.PictureBox();
            this.pbx_pl4_2 = new System.Windows.Forms.PictureBox();
            this.pbx_pl4_1 = new System.Windows.Forms.PictureBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.unk4_6 = new System.Windows.Forms.NumericUpDown();
            this.unk4_5 = new System.Windows.Forms.NumericUpDown();
            this.unk4_4 = new System.Windows.Forms.NumericUpDown();
            this.unk4_3 = new System.Windows.Forms.NumericUpDown();
            this.unk4_2 = new System.Windows.Forms.NumericUpDown();
            this.unk4_1 = new System.Windows.Forms.NumericUpDown();
            this.label12 = new System.Windows.Forms.Label();
            this.fr4_4 = new System.Windows.Forms.NumericUpDown();
            this.fr4_3 = new System.Windows.Forms.NumericUpDown();
            this.fr4_2 = new System.Windows.Forms.NumericUpDown();
            this.fr4_1 = new System.Windows.Forms.NumericUpDown();
            this.mn4_4 = new System.Windows.Forms.NumericUpDown();
            this.mn4_3 = new System.Windows.Forms.NumericUpDown();
            this.mn4_2 = new System.Windows.Forms.NumericUpDown();
            this.mn4_1 = new System.Windows.Forms.NumericUpDown();
            this.label13 = new System.Windows.Forms.Label();
            this.mx4_4 = new System.Windows.Forms.NumericUpDown();
            this.mx4_3 = new System.Windows.Forms.NumericUpDown();
            this.mx4_2 = new System.Windows.Forms.NumericUpDown();
            this.mx4_1 = new System.Windows.Forms.NumericUpDown();
            this.label14 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.pl4_4 = new System.Windows.Forms.ComboBox();
            this.pl4_1 = new System.Windows.Forms.ComboBox();
            this.pl4_3 = new System.Windows.Forms.ComboBox();
            this.pl4_2 = new System.Windows.Forms.ComboBox();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.it_48 = new System.Windows.Forms.ComboBox();
            this.it_47 = new System.Windows.Forms.ComboBox();
            this.it_46 = new System.Windows.Forms.ComboBox();
            this.it_45 = new System.Windows.Forms.ComboBox();
            this.it_44 = new System.Windows.Forms.ComboBox();
            this.it_43 = new System.Windows.Forms.ComboBox();
            this.it_42 = new System.Windows.Forms.ComboBox();
            this.it_41 = new System.Windows.Forms.ComboBox();
            this.it_38 = new System.Windows.Forms.ComboBox();
            this.it_37 = new System.Windows.Forms.ComboBox();
            this.it_36 = new System.Windows.Forms.ComboBox();
            this.it_35 = new System.Windows.Forms.ComboBox();
            this.it_34 = new System.Windows.Forms.ComboBox();
            this.it_33 = new System.Windows.Forms.ComboBox();
            this.it_32 = new System.Windows.Forms.ComboBox();
            this.it_31 = new System.Windows.Forms.ComboBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.it_14 = new System.Windows.Forms.ComboBox();
            this.label19 = new System.Windows.Forms.Label();
            this.it_11 = new System.Windows.Forms.ComboBox();
            this.label18 = new System.Windows.Forms.Label();
            this.it_12 = new System.Windows.Forms.ComboBox();
            this.label17 = new System.Windows.Forms.Label();
            this.it_13 = new System.Windows.Forms.ComboBox();
            this.label16 = new System.Windows.Forms.Label();
            this.it_15 = new System.Windows.Forms.ComboBox();
            this.it_28 = new System.Windows.Forms.ComboBox();
            this.it_16 = new System.Windows.Forms.ComboBox();
            this.it_27 = new System.Windows.Forms.ComboBox();
            this.it_17 = new System.Windows.Forms.ComboBox();
            this.it_26 = new System.Windows.Forms.ComboBox();
            this.it_18 = new System.Windows.Forms.ComboBox();
            this.it_25 = new System.Windows.Forms.ComboBox();
            this.it_21 = new System.Windows.Forms.ComboBox();
            this.it_24 = new System.Windows.Forms.ComboBox();
            this.it_22 = new System.Windows.Forms.ComboBox();
            this.it_23 = new System.Windows.Forms.ComboBox();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.label28 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.id_name = new System.Windows.Forms.ComboBox();
            this.label15 = new System.Windows.Forms.Label();
            this.save = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_pl3_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_pl3_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_pl3_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_pl3_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.unk3_6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.unk3_5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.unk3_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.unk3_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.unk3_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.unk3_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fr3_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fr3_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fr3_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fr3_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mn3_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mn3_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mn3_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mn3_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mx3_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mx3_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mx3_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mx3_1)).BeginInit();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_pl2_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_pl2_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_pl2_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_pl2_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.unk2_6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.unk2_5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.unk2_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.unk2_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.unk2_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.unk2_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fr2_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fr2_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fr2_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fr2_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mn2_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mn2_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mn2_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mn2_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mx2_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mx2_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mx2_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mx2_1)).BeginInit();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_pl1_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_pl1_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_pl1_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_pl1_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.unk1_6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.unk1_5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.unk1_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.unk1_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.unk1_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.unk1_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fr1_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fr1_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fr1_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fr1_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mn1_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mn1_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mn1_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mn1_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mx1_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mx1_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mx1_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mx1_1)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.groupBox9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_pl6_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_pl6_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_pl6_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_pl6_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.unk6_6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.unk6_5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.unk6_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.unk6_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.unk6_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.unk6_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fr6_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fr6_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fr6_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fr6_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mn6_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mn6_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mn6_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mn6_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mx6_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mx6_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mx6_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mx6_1)).BeginInit();
            this.groupBox8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_pl5_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_pl5_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_pl5_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_pl5_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.unk5_6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.unk5_5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.unk5_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.unk5_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.unk5_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.unk5_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fr5_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fr5_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fr5_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fr5_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mn5_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mn5_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mn5_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mn5_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mx5_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mx5_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mx5_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mx5_1)).BeginInit();
            this.groupBox7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_pl4_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_pl4_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_pl4_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_pl4_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.unk4_6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.unk4_5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.unk4_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.unk4_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.unk4_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.unk4_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fr4_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fr4_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fr4_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fr4_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mn4_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mn4_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mn4_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mn4_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mx4_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mx4_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mx4_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mx4_1)).BeginInit();
            this.tabPage4.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(5, 7);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 1;
            this.button1.Text = "Open NARC";
            this.toolTip1.SetToolTip(this.button1, "Open narc file by pressing this button.\r\n\r\nremember it will work fine with a/2/7/" +
        "3 .");
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Enabled = false;
            this.button2.Location = new System.Drawing.Point(87, 7);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 2;
            this.button2.Text = "Save NARC";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(24, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "ID :";
            // 
            // id_list
            // 
            this.id_list.DisplayMember = "Value";
            this.id_list.Enabled = false;
            this.id_list.FormattingEnabled = true;
            this.id_list.Location = new System.Drawing.Point(29, 41);
            this.id_list.Name = "id_list";
            this.id_list.Size = new System.Drawing.Size(49, 21);
            this.id_list.TabIndex = 4;
            this.toolTip1.SetToolTip(this.id_list, "ID for file on the narc");
            this.id_list.ValueMember = "Value";
            // 
            // tabControl1
            // 
            this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Enabled = false;
            this.tabControl1.Location = new System.Drawing.Point(6, 70);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(580, 469);
            this.tabControl1.TabIndex = 9;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.groupBox10);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.label41);
            this.tabPage1.Controls.Add(this.label37);
            this.tabPage1.Controls.Add(this.groupBox5);
            this.tabPage1.Controls.Add(this.groupBox4);
            this.tabPage1.Controls.Add(this.label21);
            this.tabPage1.Controls.Add(this.groupBox3);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(572, 443);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Pokémon W2";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.button6);
            this.groupBox10.Controls.Add(this.button4);
            this.groupBox10.Location = new System.Drawing.Point(366, 390);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(200, 41);
            this.groupBox10.TabIndex = 160;
            this.groupBox10.TabStop = false;
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(6, 12);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(75, 23);
            this.button6.TabIndex = 159;
            this.button6.Text = "Swap";
            this.toolTip1.SetToolTip(this.button6, "Swap W2 pokemon table list with B2 pokemon table list.");
            this.button6.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(86, 12);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(108, 23);
            this.button4.TabIndex = 157;
            this.button4.Text = "Copy to B2 list >";
            this.button4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.toolTip1.SetToolTip(this.button4, "Just for copying W2 pokemon table list into B2 pokemon table list.");
            this.button4.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(-1, 316);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(36, 26);
            this.label6.TabIndex = 153;
            this.label6.Text = "C \r\n(15 %)\r\n";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(20, 396);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(159, 13);
            this.label41.TabIndex = 156;
            this.label41.Text = "[!] = need edit overworld texture.\r\n";
            this.toolTip1.SetToolTip(this.label41, "pokemon with [!] mark and if pokemon just have 1 forme \r\n(if you change forme val" +
        "ue into >0) it will become blue man sprite.\r\n");
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(3, 186);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(30, 26);
            this.label37.TabIndex = 99;
            this.label37.Text = "B \r\n(4 %)";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.pbx_pl3_2);
            this.groupBox5.Controls.Add(this.pbx_pl3_4);
            this.groupBox5.Controls.Add(this.pbx_pl3_3);
            this.groupBox5.Controls.Add(this.pbx_pl3_1);
            this.groupBox5.Controls.Add(this.label7);
            this.groupBox5.Controls.Add(this.label8);
            this.groupBox5.Controls.Add(this.unk3_6);
            this.groupBox5.Controls.Add(this.unk3_5);
            this.groupBox5.Controls.Add(this.unk3_4);
            this.groupBox5.Controls.Add(this.unk3_3);
            this.groupBox5.Controls.Add(this.unk3_2);
            this.groupBox5.Controls.Add(this.unk3_1);
            this.groupBox5.Controls.Add(this.label9);
            this.groupBox5.Controls.Add(this.fr3_4);
            this.groupBox5.Controls.Add(this.fr3_3);
            this.groupBox5.Controls.Add(this.fr3_2);
            this.groupBox5.Controls.Add(this.fr3_1);
            this.groupBox5.Controls.Add(this.mn3_4);
            this.groupBox5.Controls.Add(this.mn3_3);
            this.groupBox5.Controls.Add(this.mn3_2);
            this.groupBox5.Controls.Add(this.mn3_1);
            this.groupBox5.Controls.Add(this.label26);
            this.groupBox5.Controls.Add(this.mx3_4);
            this.groupBox5.Controls.Add(this.mx3_3);
            this.groupBox5.Controls.Add(this.mx3_2);
            this.groupBox5.Controls.Add(this.mx3_1);
            this.groupBox5.Controls.Add(this.label38);
            this.groupBox5.Controls.Add(this.label39);
            this.groupBox5.Controls.Add(this.pl3_4);
            this.groupBox5.Controls.Add(this.pl3_1);
            this.groupBox5.Controls.Add(this.pl3_3);
            this.groupBox5.Controls.Add(this.pl3_2);
            this.groupBox5.Location = new System.Drawing.Point(23, 262);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(543, 128);
            this.groupBox5.TabIndex = 152;
            this.groupBox5.TabStop = false;
            // 
            // pbx_pl3_2
            // 
            this.pbx_pl3_2.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pbx_pl3_2.ErrorImage")));
            this.pbx_pl3_2.ImageLocation = "";
            this.pbx_pl3_2.InitialImage = ((System.Drawing.Image)(resources.GetObject("pbx_pl3_2.InitialImage")));
            this.pbx_pl3_2.Location = new System.Drawing.Point(10, 39);
            this.pbx_pl3_2.Margin = new System.Windows.Forms.Padding(0);
            this.pbx_pl3_2.Name = "pbx_pl3_2";
            this.pbx_pl3_2.Size = new System.Drawing.Size(29, 33);
            this.pbx_pl3_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pbx_pl3_2.TabIndex = 157;
            this.pbx_pl3_2.TabStop = false;
            // 
            // pbx_pl3_4
            // 
            this.pbx_pl3_4.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pbx_pl3_4.ErrorImage")));
            this.pbx_pl3_4.ImageLocation = "";
            this.pbx_pl3_4.InitialImage = ((System.Drawing.Image)(resources.GetObject("pbx_pl3_4.InitialImage")));
            this.pbx_pl3_4.Location = new System.Drawing.Point(10, 87);
            this.pbx_pl3_4.Margin = new System.Windows.Forms.Padding(0);
            this.pbx_pl3_4.Name = "pbx_pl3_4";
            this.pbx_pl3_4.Size = new System.Drawing.Size(29, 33);
            this.pbx_pl3_4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pbx_pl3_4.TabIndex = 159;
            this.pbx_pl3_4.TabStop = false;
            // 
            // pbx_pl3_3
            // 
            this.pbx_pl3_3.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pbx_pl3_3.ErrorImage")));
            this.pbx_pl3_3.ImageLocation = "";
            this.pbx_pl3_3.InitialImage = ((System.Drawing.Image)(resources.GetObject("pbx_pl3_3.InitialImage")));
            this.pbx_pl3_3.Location = new System.Drawing.Point(39, 63);
            this.pbx_pl3_3.Margin = new System.Windows.Forms.Padding(0);
            this.pbx_pl3_3.Name = "pbx_pl3_3";
            this.pbx_pl3_3.Size = new System.Drawing.Size(29, 33);
            this.pbx_pl3_3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pbx_pl3_3.TabIndex = 158;
            this.pbx_pl3_3.TabStop = false;
            // 
            // pbx_pl3_1
            // 
            this.pbx_pl3_1.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pbx_pl3_1.ErrorImage")));
            this.pbx_pl3_1.ImageLocation = "";
            this.pbx_pl3_1.InitialImage = ((System.Drawing.Image)(resources.GetObject("pbx_pl3_1.InitialImage")));
            this.pbx_pl3_1.Location = new System.Drawing.Point(39, 15);
            this.pbx_pl3_1.Margin = new System.Windows.Forms.Padding(0);
            this.pbx_pl3_1.Name = "pbx_pl3_1";
            this.pbx_pl3_1.Size = new System.Drawing.Size(29, 33);
            this.pbx_pl3_1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pbx_pl3_1.TabIndex = 156;
            this.pbx_pl3_1.TabStop = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(463, 10);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(13, 13);
            this.label7.TabIndex = 151;
            this.label7.Text = "?";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(397, 10);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(33, 13);
            this.label8.TabIndex = 150;
            this.label8.Text = "forme";
            // 
            // unk3_6
            // 
            this.unk3_6.Enabled = false;
            this.unk3_6.Location = new System.Drawing.Point(466, 51);
            this.unk3_6.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.unk3_6.Name = "unk3_6";
            this.unk3_6.Size = new System.Drawing.Size(70, 20);
            this.unk3_6.TabIndex = 148;
            // 
            // unk3_5
            // 
            this.unk3_5.Enabled = false;
            this.unk3_5.Location = new System.Drawing.Point(466, 26);
            this.unk3_5.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.unk3_5.Name = "unk3_5";
            this.unk3_5.Size = new System.Drawing.Size(70, 20);
            this.unk3_5.TabIndex = 147;
            // 
            // unk3_4
            // 
            this.unk3_4.Location = new System.Drawing.Point(400, 99);
            this.unk3_4.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.unk3_4.Name = "unk3_4";
            this.unk3_4.Size = new System.Drawing.Size(57, 20);
            this.unk3_4.TabIndex = 146;
            // 
            // unk3_3
            // 
            this.unk3_3.Location = new System.Drawing.Point(400, 75);
            this.unk3_3.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.unk3_3.Name = "unk3_3";
            this.unk3_3.Size = new System.Drawing.Size(57, 20);
            this.unk3_3.TabIndex = 145;
            // 
            // unk3_2
            // 
            this.unk3_2.Location = new System.Drawing.Point(400, 51);
            this.unk3_2.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.unk3_2.Name = "unk3_2";
            this.unk3_2.Size = new System.Drawing.Size(57, 20);
            this.unk3_2.TabIndex = 144;
            // 
            // unk3_1
            // 
            this.unk3_1.Location = new System.Drawing.Point(400, 27);
            this.unk3_1.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.unk3_1.Name = "unk3_1";
            this.unk3_1.Size = new System.Drawing.Size(57, 20);
            this.unk3_1.TabIndex = 149;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(331, 11);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(49, 13);
            this.label9.TabIndex = 143;
            this.label9.Text = "% female";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // fr3_4
            // 
            this.fr3_4.Location = new System.Drawing.Point(334, 99);
            this.fr3_4.Name = "fr3_4";
            this.fr3_4.Size = new System.Drawing.Size(49, 20);
            this.fr3_4.TabIndex = 142;
            // 
            // fr3_3
            // 
            this.fr3_3.Location = new System.Drawing.Point(334, 74);
            this.fr3_3.Name = "fr3_3";
            this.fr3_3.Size = new System.Drawing.Size(49, 20);
            this.fr3_3.TabIndex = 141;
            // 
            // fr3_2
            // 
            this.fr3_2.Location = new System.Drawing.Point(334, 50);
            this.fr3_2.Name = "fr3_2";
            this.fr3_2.Size = new System.Drawing.Size(49, 20);
            this.fr3_2.TabIndex = 140;
            // 
            // fr3_1
            // 
            this.fr3_1.Location = new System.Drawing.Point(334, 27);
            this.fr3_1.Name = "fr3_1";
            this.fr3_1.Size = new System.Drawing.Size(49, 20);
            this.fr3_1.TabIndex = 139;
            // 
            // mn3_4
            // 
            this.mn3_4.Location = new System.Drawing.Point(282, 98);
            this.mn3_4.Name = "mn3_4";
            this.mn3_4.Size = new System.Drawing.Size(46, 20);
            this.mn3_4.TabIndex = 138;
            // 
            // mn3_3
            // 
            this.mn3_3.Location = new System.Drawing.Point(282, 74);
            this.mn3_3.Name = "mn3_3";
            this.mn3_3.Size = new System.Drawing.Size(46, 20);
            this.mn3_3.TabIndex = 137;
            // 
            // mn3_2
            // 
            this.mn3_2.Location = new System.Drawing.Point(282, 50);
            this.mn3_2.Name = "mn3_2";
            this.mn3_2.Size = new System.Drawing.Size(46, 20);
            this.mn3_2.TabIndex = 136;
            // 
            // mn3_1
            // 
            this.mn3_1.Location = new System.Drawing.Point(282, 26);
            this.mn3_1.Name = "mn3_1";
            this.mn3_1.Size = new System.Drawing.Size(46, 20);
            this.mn3_1.TabIndex = 135;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(279, 10);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(24, 13);
            this.label26.TabIndex = 134;
            this.label26.Text = "Min";
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // mx3_4
            // 
            this.mx3_4.Location = new System.Drawing.Point(230, 98);
            this.mx3_4.Name = "mx3_4";
            this.mx3_4.Size = new System.Drawing.Size(46, 20);
            this.mx3_4.TabIndex = 133;
            // 
            // mx3_3
            // 
            this.mx3_3.Location = new System.Drawing.Point(230, 74);
            this.mx3_3.Name = "mx3_3";
            this.mx3_3.Size = new System.Drawing.Size(46, 20);
            this.mx3_3.TabIndex = 132;
            // 
            // mx3_2
            // 
            this.mx3_2.Location = new System.Drawing.Point(230, 50);
            this.mx3_2.Name = "mx3_2";
            this.mx3_2.Size = new System.Drawing.Size(46, 20);
            this.mx3_2.TabIndex = 131;
            // 
            // mx3_1
            // 
            this.mx3_1.Location = new System.Drawing.Point(230, 26);
            this.mx3_1.Name = "mx3_1";
            this.mx3_1.Size = new System.Drawing.Size(46, 20);
            this.mx3_1.TabIndex = 130;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(227, 10);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(27, 13);
            this.label38.TabIndex = 129;
            this.label38.Text = "Max";
            this.label38.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(72, 11);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(58, 13);
            this.label39.TabIndex = 125;
            this.label39.Text = "Pokémon :";
            this.label39.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // pl3_4
            // 
            this.pl3_4.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.pl3_4.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.pl3_4.DisplayMember = "Name";
            this.pl3_4.DropDownHeight = 140;
            this.pl3_4.DropDownWidth = 150;
            this.pl3_4.FormattingEnabled = true;
            this.pl3_4.IntegralHeight = false;
            this.pl3_4.Location = new System.Drawing.Point(75, 99);
            this.pl3_4.Name = "pl3_4";
            this.pl3_4.Size = new System.Drawing.Size(119, 21);
            this.pl3_4.TabIndex = 128;
            this.pl3_4.ValueMember = "Value";
            // 
            // pl3_1
            // 
            this.pl3_1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.pl3_1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.pl3_1.DisplayMember = "Name";
            this.pl3_1.DropDownHeight = 140;
            this.pl3_1.DropDownWidth = 150;
            this.pl3_1.FormattingEnabled = true;
            this.pl3_1.IntegralHeight = false;
            this.pl3_1.Location = new System.Drawing.Point(75, 27);
            this.pl3_1.Name = "pl3_1";
            this.pl3_1.Size = new System.Drawing.Size(119, 21);
            this.pl3_1.TabIndex = 124;
            this.pl3_1.ValueMember = "Value";
            // 
            // pl3_3
            // 
            this.pl3_3.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.pl3_3.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.pl3_3.DisplayMember = "Name";
            this.pl3_3.DropDownHeight = 140;
            this.pl3_3.DropDownWidth = 150;
            this.pl3_3.FormattingEnabled = true;
            this.pl3_3.IntegralHeight = false;
            this.pl3_3.Location = new System.Drawing.Point(75, 75);
            this.pl3_3.Name = "pl3_3";
            this.pl3_3.Size = new System.Drawing.Size(119, 21);
            this.pl3_3.TabIndex = 127;
            this.pl3_3.ValueMember = "Value";
            // 
            // pl3_2
            // 
            this.pl3_2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.pl3_2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.pl3_2.DisplayMember = "Name";
            this.pl3_2.DropDownHeight = 140;
            this.pl3_2.DropDownWidth = 150;
            this.pl3_2.FormattingEnabled = true;
            this.pl3_2.IntegralHeight = false;
            this.pl3_2.Location = new System.Drawing.Point(75, 51);
            this.pl3_2.Name = "pl3_2";
            this.pl3_2.Size = new System.Drawing.Size(119, 21);
            this.pl3_2.TabIndex = 126;
            this.pl3_2.ValueMember = "Value";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.pbx_pl2_4);
            this.groupBox4.Controls.Add(this.pbx_pl2_3);
            this.groupBox4.Controls.Add(this.pbx_pl2_2);
            this.groupBox4.Controls.Add(this.pbx_pl2_1);
            this.groupBox4.Controls.Add(this.label22);
            this.groupBox4.Controls.Add(this.label23);
            this.groupBox4.Controls.Add(this.unk2_6);
            this.groupBox4.Controls.Add(this.unk2_5);
            this.groupBox4.Controls.Add(this.unk2_4);
            this.groupBox4.Controls.Add(this.unk2_3);
            this.groupBox4.Controls.Add(this.unk2_2);
            this.groupBox4.Controls.Add(this.unk2_1);
            this.groupBox4.Controls.Add(this.label33);
            this.groupBox4.Controls.Add(this.fr2_4);
            this.groupBox4.Controls.Add(this.fr2_3);
            this.groupBox4.Controls.Add(this.fr2_2);
            this.groupBox4.Controls.Add(this.fr2_1);
            this.groupBox4.Controls.Add(this.mn2_4);
            this.groupBox4.Controls.Add(this.mn2_3);
            this.groupBox4.Controls.Add(this.mn2_2);
            this.groupBox4.Controls.Add(this.mn2_1);
            this.groupBox4.Controls.Add(this.label34);
            this.groupBox4.Controls.Add(this.mx2_4);
            this.groupBox4.Controls.Add(this.mx2_3);
            this.groupBox4.Controls.Add(this.mx2_2);
            this.groupBox4.Controls.Add(this.mx2_1);
            this.groupBox4.Controls.Add(this.label35);
            this.groupBox4.Controls.Add(this.label36);
            this.groupBox4.Controls.Add(this.pl2_4);
            this.groupBox4.Controls.Add(this.pl2_1);
            this.groupBox4.Controls.Add(this.pl2_3);
            this.groupBox4.Controls.Add(this.pl2_2);
            this.groupBox4.Location = new System.Drawing.Point(23, 131);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(543, 128);
            this.groupBox4.TabIndex = 98;
            this.groupBox4.TabStop = false;
            // 
            // pbx_pl2_4
            // 
            this.pbx_pl2_4.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pbx_pl2_4.ErrorImage")));
            this.pbx_pl2_4.ImageLocation = "";
            this.pbx_pl2_4.InitialImage = ((System.Drawing.Image)(resources.GetObject("pbx_pl2_4.InitialImage")));
            this.pbx_pl2_4.Location = new System.Drawing.Point(10, 85);
            this.pbx_pl2_4.Margin = new System.Windows.Forms.Padding(0);
            this.pbx_pl2_4.Name = "pbx_pl2_4";
            this.pbx_pl2_4.Size = new System.Drawing.Size(29, 33);
            this.pbx_pl2_4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pbx_pl2_4.TabIndex = 155;
            this.pbx_pl2_4.TabStop = false;
            // 
            // pbx_pl2_3
            // 
            this.pbx_pl2_3.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pbx_pl2_3.ErrorImage")));
            this.pbx_pl2_3.ImageLocation = "";
            this.pbx_pl2_3.InitialImage = ((System.Drawing.Image)(resources.GetObject("pbx_pl2_3.InitialImage")));
            this.pbx_pl2_3.Location = new System.Drawing.Point(39, 62);
            this.pbx_pl2_3.Margin = new System.Windows.Forms.Padding(0);
            this.pbx_pl2_3.Name = "pbx_pl2_3";
            this.pbx_pl2_3.Size = new System.Drawing.Size(29, 33);
            this.pbx_pl2_3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pbx_pl2_3.TabIndex = 154;
            this.pbx_pl2_3.TabStop = false;
            // 
            // pbx_pl2_2
            // 
            this.pbx_pl2_2.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pbx_pl2_2.ErrorImage")));
            this.pbx_pl2_2.ImageLocation = "";
            this.pbx_pl2_2.InitialImage = ((System.Drawing.Image)(resources.GetObject("pbx_pl2_2.InitialImage")));
            this.pbx_pl2_2.Location = new System.Drawing.Point(10, 38);
            this.pbx_pl2_2.Margin = new System.Windows.Forms.Padding(0);
            this.pbx_pl2_2.Name = "pbx_pl2_2";
            this.pbx_pl2_2.Size = new System.Drawing.Size(29, 33);
            this.pbx_pl2_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pbx_pl2_2.TabIndex = 153;
            this.pbx_pl2_2.TabStop = false;
            // 
            // pbx_pl2_1
            // 
            this.pbx_pl2_1.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pbx_pl2_1.ErrorImage")));
            this.pbx_pl2_1.ImageLocation = "";
            this.pbx_pl2_1.InitialImage = ((System.Drawing.Image)(resources.GetObject("pbx_pl2_1.InitialImage")));
            this.pbx_pl2_1.Location = new System.Drawing.Point(39, 13);
            this.pbx_pl2_1.Margin = new System.Windows.Forms.Padding(0);
            this.pbx_pl2_1.Name = "pbx_pl2_1";
            this.pbx_pl2_1.Size = new System.Drawing.Size(29, 33);
            this.pbx_pl2_1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pbx_pl2_1.TabIndex = 152;
            this.pbx_pl2_1.TabStop = false;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(463, 10);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(13, 13);
            this.label22.TabIndex = 151;
            this.label22.Text = "?";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(397, 10);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(33, 13);
            this.label23.TabIndex = 150;
            this.label23.Text = "forme";
            // 
            // unk2_6
            // 
            this.unk2_6.Enabled = false;
            this.unk2_6.Location = new System.Drawing.Point(466, 51);
            this.unk2_6.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.unk2_6.Name = "unk2_6";
            this.unk2_6.Size = new System.Drawing.Size(70, 20);
            this.unk2_6.TabIndex = 148;
            // 
            // unk2_5
            // 
            this.unk2_5.Enabled = false;
            this.unk2_5.Location = new System.Drawing.Point(466, 26);
            this.unk2_5.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.unk2_5.Name = "unk2_5";
            this.unk2_5.Size = new System.Drawing.Size(70, 20);
            this.unk2_5.TabIndex = 147;
            // 
            // unk2_4
            // 
            this.unk2_4.Location = new System.Drawing.Point(400, 99);
            this.unk2_4.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.unk2_4.Name = "unk2_4";
            this.unk2_4.Size = new System.Drawing.Size(57, 20);
            this.unk2_4.TabIndex = 146;
            // 
            // unk2_3
            // 
            this.unk2_3.Location = new System.Drawing.Point(400, 75);
            this.unk2_3.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.unk2_3.Name = "unk2_3";
            this.unk2_3.Size = new System.Drawing.Size(57, 20);
            this.unk2_3.TabIndex = 145;
            // 
            // unk2_2
            // 
            this.unk2_2.Location = new System.Drawing.Point(400, 51);
            this.unk2_2.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.unk2_2.Name = "unk2_2";
            this.unk2_2.Size = new System.Drawing.Size(57, 20);
            this.unk2_2.TabIndex = 144;
            // 
            // unk2_1
            // 
            this.unk2_1.Location = new System.Drawing.Point(400, 27);
            this.unk2_1.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.unk2_1.Name = "unk2_1";
            this.unk2_1.Size = new System.Drawing.Size(57, 20);
            this.unk2_1.TabIndex = 149;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(331, 11);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(49, 13);
            this.label33.TabIndex = 143;
            this.label33.Text = "% female";
            this.label33.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // fr2_4
            // 
            this.fr2_4.Location = new System.Drawing.Point(334, 99);
            this.fr2_4.Name = "fr2_4";
            this.fr2_4.Size = new System.Drawing.Size(49, 20);
            this.fr2_4.TabIndex = 142;
            // 
            // fr2_3
            // 
            this.fr2_3.Location = new System.Drawing.Point(334, 74);
            this.fr2_3.Name = "fr2_3";
            this.fr2_3.Size = new System.Drawing.Size(49, 20);
            this.fr2_3.TabIndex = 141;
            // 
            // fr2_2
            // 
            this.fr2_2.Location = new System.Drawing.Point(334, 50);
            this.fr2_2.Name = "fr2_2";
            this.fr2_2.Size = new System.Drawing.Size(49, 20);
            this.fr2_2.TabIndex = 140;
            // 
            // fr2_1
            // 
            this.fr2_1.Location = new System.Drawing.Point(334, 27);
            this.fr2_1.Name = "fr2_1";
            this.fr2_1.Size = new System.Drawing.Size(49, 20);
            this.fr2_1.TabIndex = 139;
            // 
            // mn2_4
            // 
            this.mn2_4.Location = new System.Drawing.Point(282, 98);
            this.mn2_4.Name = "mn2_4";
            this.mn2_4.Size = new System.Drawing.Size(46, 20);
            this.mn2_4.TabIndex = 138;
            // 
            // mn2_3
            // 
            this.mn2_3.Location = new System.Drawing.Point(282, 74);
            this.mn2_3.Name = "mn2_3";
            this.mn2_3.Size = new System.Drawing.Size(46, 20);
            this.mn2_3.TabIndex = 137;
            // 
            // mn2_2
            // 
            this.mn2_2.Location = new System.Drawing.Point(282, 50);
            this.mn2_2.Name = "mn2_2";
            this.mn2_2.Size = new System.Drawing.Size(46, 20);
            this.mn2_2.TabIndex = 136;
            // 
            // mn2_1
            // 
            this.mn2_1.Location = new System.Drawing.Point(282, 26);
            this.mn2_1.Name = "mn2_1";
            this.mn2_1.Size = new System.Drawing.Size(46, 20);
            this.mn2_1.TabIndex = 135;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(279, 10);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(24, 13);
            this.label34.TabIndex = 134;
            this.label34.Text = "Min";
            this.label34.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // mx2_4
            // 
            this.mx2_4.Location = new System.Drawing.Point(230, 98);
            this.mx2_4.Name = "mx2_4";
            this.mx2_4.Size = new System.Drawing.Size(46, 20);
            this.mx2_4.TabIndex = 133;
            // 
            // mx2_3
            // 
            this.mx2_3.Location = new System.Drawing.Point(230, 74);
            this.mx2_3.Name = "mx2_3";
            this.mx2_3.Size = new System.Drawing.Size(46, 20);
            this.mx2_3.TabIndex = 132;
            // 
            // mx2_2
            // 
            this.mx2_2.Location = new System.Drawing.Point(230, 50);
            this.mx2_2.Name = "mx2_2";
            this.mx2_2.Size = new System.Drawing.Size(46, 20);
            this.mx2_2.TabIndex = 131;
            // 
            // mx2_1
            // 
            this.mx2_1.Location = new System.Drawing.Point(230, 26);
            this.mx2_1.Name = "mx2_1";
            this.mx2_1.Size = new System.Drawing.Size(46, 20);
            this.mx2_1.TabIndex = 130;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(227, 10);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(27, 13);
            this.label35.TabIndex = 129;
            this.label35.Text = "Max";
            this.label35.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(72, 10);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(58, 13);
            this.label36.TabIndex = 125;
            this.label36.Text = "Pokémon :";
            this.label36.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // pl2_4
            // 
            this.pl2_4.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.pl2_4.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.pl2_4.DisplayMember = "Name";
            this.pl2_4.DropDownHeight = 140;
            this.pl2_4.DropDownWidth = 150;
            this.pl2_4.FormattingEnabled = true;
            this.pl2_4.IntegralHeight = false;
            this.pl2_4.Location = new System.Drawing.Point(75, 98);
            this.pl2_4.Name = "pl2_4";
            this.pl2_4.Size = new System.Drawing.Size(119, 21);
            this.pl2_4.TabIndex = 128;
            this.pl2_4.ValueMember = "Value";
            // 
            // pl2_1
            // 
            this.pl2_1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.pl2_1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.pl2_1.DisplayMember = "Name";
            this.pl2_1.DropDownHeight = 140;
            this.pl2_1.DropDownWidth = 150;
            this.pl2_1.FormattingEnabled = true;
            this.pl2_1.IntegralHeight = false;
            this.pl2_1.Location = new System.Drawing.Point(75, 26);
            this.pl2_1.Name = "pl2_1";
            this.pl2_1.Size = new System.Drawing.Size(119, 21);
            this.pl2_1.TabIndex = 124;
            this.pl2_1.ValueMember = "Value";
            // 
            // pl2_3
            // 
            this.pl2_3.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.pl2_3.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.pl2_3.DisplayMember = "Name";
            this.pl2_3.DropDownHeight = 140;
            this.pl2_3.DropDownWidth = 150;
            this.pl2_3.FormattingEnabled = true;
            this.pl2_3.IntegralHeight = false;
            this.pl2_3.Location = new System.Drawing.Point(75, 74);
            this.pl2_3.Name = "pl2_3";
            this.pl2_3.Size = new System.Drawing.Size(119, 21);
            this.pl2_3.TabIndex = 127;
            this.pl2_3.ValueMember = "Value";
            // 
            // pl2_2
            // 
            this.pl2_2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.pl2_2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.pl2_2.DisplayMember = "Name";
            this.pl2_2.DropDownHeight = 140;
            this.pl2_2.DropDownWidth = 150;
            this.pl2_2.FormattingEnabled = true;
            this.pl2_2.IntegralHeight = false;
            this.pl2_2.Location = new System.Drawing.Point(75, 50);
            this.pl2_2.Name = "pl2_2";
            this.pl2_2.Size = new System.Drawing.Size(119, 21);
            this.pl2_2.TabIndex = 126;
            this.pl2_2.ValueMember = "Value";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(3, 53);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(30, 26);
            this.label21.TabIndex = 97;
            this.label21.Text = "A \r\n(1 %)";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.pbx_pl1_4);
            this.groupBox3.Controls.Add(this.pbx_pl1_3);
            this.groupBox3.Controls.Add(this.pbx_pl1_2);
            this.groupBox3.Controls.Add(this.pbx_pl1_1);
            this.groupBox3.Controls.Add(this.label20);
            this.groupBox3.Controls.Add(this.label27);
            this.groupBox3.Controls.Add(this.unk1_6);
            this.groupBox3.Controls.Add(this.unk1_5);
            this.groupBox3.Controls.Add(this.unk1_4);
            this.groupBox3.Controls.Add(this.unk1_3);
            this.groupBox3.Controls.Add(this.unk1_2);
            this.groupBox3.Controls.Add(this.unk1_1);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.fr1_4);
            this.groupBox3.Controls.Add(this.fr1_3);
            this.groupBox3.Controls.Add(this.fr1_2);
            this.groupBox3.Controls.Add(this.fr1_1);
            this.groupBox3.Controls.Add(this.mn1_4);
            this.groupBox3.Controls.Add(this.mn1_3);
            this.groupBox3.Controls.Add(this.mn1_2);
            this.groupBox3.Controls.Add(this.mn1_1);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.mx1_4);
            this.groupBox3.Controls.Add(this.mx1_3);
            this.groupBox3.Controls.Add(this.mx1_2);
            this.groupBox3.Controls.Add(this.mx1_1);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Controls.Add(this.pl1_4);
            this.groupBox3.Controls.Add(this.pl1_1);
            this.groupBox3.Controls.Add(this.pl1_3);
            this.groupBox3.Controls.Add(this.pl1_2);
            this.groupBox3.Location = new System.Drawing.Point(23, 0);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(543, 130);
            this.groupBox3.TabIndex = 96;
            this.groupBox3.TabStop = false;
            // 
            // pbx_pl1_4
            // 
            this.pbx_pl1_4.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pbx_pl1_4.ErrorImage")));
            this.pbx_pl1_4.ImageLocation = "";
            this.pbx_pl1_4.InitialImage = ((System.Drawing.Image)(resources.GetObject("pbx_pl1_4.InitialImage")));
            this.pbx_pl1_4.Location = new System.Drawing.Point(10, 86);
            this.pbx_pl1_4.Margin = new System.Windows.Forms.Padding(0);
            this.pbx_pl1_4.Name = "pbx_pl1_4";
            this.pbx_pl1_4.Size = new System.Drawing.Size(29, 33);
            this.pbx_pl1_4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pbx_pl1_4.TabIndex = 127;
            this.pbx_pl1_4.TabStop = false;
            // 
            // pbx_pl1_3
            // 
            this.pbx_pl1_3.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pbx_pl1_3.ErrorImage")));
            this.pbx_pl1_3.ImageLocation = "";
            this.pbx_pl1_3.InitialImage = ((System.Drawing.Image)(resources.GetObject("pbx_pl1_3.InitialImage")));
            this.pbx_pl1_3.Location = new System.Drawing.Point(39, 62);
            this.pbx_pl1_3.Margin = new System.Windows.Forms.Padding(0);
            this.pbx_pl1_3.Name = "pbx_pl1_3";
            this.pbx_pl1_3.Size = new System.Drawing.Size(29, 33);
            this.pbx_pl1_3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pbx_pl1_3.TabIndex = 126;
            this.pbx_pl1_3.TabStop = false;
            // 
            // pbx_pl1_2
            // 
            this.pbx_pl1_2.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pbx_pl1_2.ErrorImage")));
            this.pbx_pl1_2.ImageLocation = "";
            this.pbx_pl1_2.InitialImage = ((System.Drawing.Image)(resources.GetObject("pbx_pl1_2.InitialImage")));
            this.pbx_pl1_2.Location = new System.Drawing.Point(10, 38);
            this.pbx_pl1_2.Margin = new System.Windows.Forms.Padding(0);
            this.pbx_pl1_2.Name = "pbx_pl1_2";
            this.pbx_pl1_2.Size = new System.Drawing.Size(29, 33);
            this.pbx_pl1_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pbx_pl1_2.TabIndex = 125;
            this.pbx_pl1_2.TabStop = false;
            // 
            // pbx_pl1_1
            // 
            this.pbx_pl1_1.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pbx_pl1_1.ErrorImage")));
            this.pbx_pl1_1.ImageLocation = "";
            this.pbx_pl1_1.InitialImage = ((System.Drawing.Image)(resources.GetObject("pbx_pl1_1.InitialImage")));
            this.pbx_pl1_1.Location = new System.Drawing.Point(39, 14);
            this.pbx_pl1_1.Margin = new System.Windows.Forms.Padding(0);
            this.pbx_pl1_1.Name = "pbx_pl1_1";
            this.pbx_pl1_1.Size = new System.Drawing.Size(29, 33);
            this.pbx_pl1_1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pbx_pl1_1.TabIndex = 124;
            this.pbx_pl1_1.TabStop = false;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(462, 10);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(13, 13);
            this.label20.TabIndex = 123;
            this.label20.Text = "?";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(397, 10);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(33, 13);
            this.label27.TabIndex = 122;
            this.label27.Text = "forme";
            // 
            // unk1_6
            // 
            this.unk1_6.Enabled = false;
            this.unk1_6.Location = new System.Drawing.Point(465, 51);
            this.unk1_6.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.unk1_6.Name = "unk1_6";
            this.unk1_6.Size = new System.Drawing.Size(70, 20);
            this.unk1_6.TabIndex = 120;
            // 
            // unk1_5
            // 
            this.unk1_5.Enabled = false;
            this.unk1_5.Location = new System.Drawing.Point(465, 26);
            this.unk1_5.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.unk1_5.Name = "unk1_5";
            this.unk1_5.Size = new System.Drawing.Size(70, 20);
            this.unk1_5.TabIndex = 119;
            // 
            // unk1_4
            // 
            this.unk1_4.Location = new System.Drawing.Point(400, 99);
            this.unk1_4.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.unk1_4.Name = "unk1_4";
            this.unk1_4.Size = new System.Drawing.Size(57, 20);
            this.unk1_4.TabIndex = 118;
            // 
            // unk1_3
            // 
            this.unk1_3.Location = new System.Drawing.Point(400, 75);
            this.unk1_3.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.unk1_3.Name = "unk1_3";
            this.unk1_3.Size = new System.Drawing.Size(57, 20);
            this.unk1_3.TabIndex = 117;
            // 
            // unk1_2
            // 
            this.unk1_2.Location = new System.Drawing.Point(400, 51);
            this.unk1_2.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.unk1_2.Name = "unk1_2";
            this.unk1_2.Size = new System.Drawing.Size(57, 20);
            this.unk1_2.TabIndex = 116;
            // 
            // unk1_1
            // 
            this.unk1_1.Location = new System.Drawing.Point(400, 27);
            this.unk1_1.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.unk1_1.Name = "unk1_1";
            this.unk1_1.Size = new System.Drawing.Size(57, 20);
            this.unk1_1.TabIndex = 121;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(331, 11);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(49, 13);
            this.label5.TabIndex = 115;
            this.label5.Text = "% female";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // fr1_4
            // 
            this.fr1_4.Location = new System.Drawing.Point(334, 99);
            this.fr1_4.Name = "fr1_4";
            this.fr1_4.Size = new System.Drawing.Size(49, 20);
            this.fr1_4.TabIndex = 114;
            // 
            // fr1_3
            // 
            this.fr1_3.Location = new System.Drawing.Point(334, 74);
            this.fr1_3.Name = "fr1_3";
            this.fr1_3.Size = new System.Drawing.Size(49, 20);
            this.fr1_3.TabIndex = 113;
            // 
            // fr1_2
            // 
            this.fr1_2.Location = new System.Drawing.Point(334, 50);
            this.fr1_2.Name = "fr1_2";
            this.fr1_2.Size = new System.Drawing.Size(49, 20);
            this.fr1_2.TabIndex = 112;
            // 
            // fr1_1
            // 
            this.fr1_1.Location = new System.Drawing.Point(334, 27);
            this.fr1_1.Name = "fr1_1";
            this.fr1_1.Size = new System.Drawing.Size(49, 20);
            this.fr1_1.TabIndex = 111;
            // 
            // mn1_4
            // 
            this.mn1_4.Location = new System.Drawing.Point(282, 98);
            this.mn1_4.Name = "mn1_4";
            this.mn1_4.Size = new System.Drawing.Size(46, 20);
            this.mn1_4.TabIndex = 110;
            // 
            // mn1_3
            // 
            this.mn1_3.Location = new System.Drawing.Point(282, 74);
            this.mn1_3.Name = "mn1_3";
            this.mn1_3.Size = new System.Drawing.Size(46, 20);
            this.mn1_3.TabIndex = 109;
            // 
            // mn1_2
            // 
            this.mn1_2.Location = new System.Drawing.Point(282, 50);
            this.mn1_2.Name = "mn1_2";
            this.mn1_2.Size = new System.Drawing.Size(46, 20);
            this.mn1_2.TabIndex = 108;
            // 
            // mn1_1
            // 
            this.mn1_1.Location = new System.Drawing.Point(282, 26);
            this.mn1_1.Name = "mn1_1";
            this.mn1_1.Size = new System.Drawing.Size(46, 20);
            this.mn1_1.TabIndex = 107;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(279, 10);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(24, 13);
            this.label4.TabIndex = 106;
            this.label4.Text = "Min";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // mx1_4
            // 
            this.mx1_4.Location = new System.Drawing.Point(230, 98);
            this.mx1_4.Name = "mx1_4";
            this.mx1_4.Size = new System.Drawing.Size(46, 20);
            this.mx1_4.TabIndex = 105;
            // 
            // mx1_3
            // 
            this.mx1_3.Location = new System.Drawing.Point(230, 74);
            this.mx1_3.Name = "mx1_3";
            this.mx1_3.Size = new System.Drawing.Size(46, 20);
            this.mx1_3.TabIndex = 104;
            // 
            // mx1_2
            // 
            this.mx1_2.Location = new System.Drawing.Point(230, 50);
            this.mx1_2.Name = "mx1_2";
            this.mx1_2.Size = new System.Drawing.Size(46, 20);
            this.mx1_2.TabIndex = 103;
            // 
            // mx1_1
            // 
            this.mx1_1.Location = new System.Drawing.Point(230, 26);
            this.mx1_1.Name = "mx1_1";
            this.mx1_1.Size = new System.Drawing.Size(46, 20);
            this.mx1_1.TabIndex = 102;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(227, 10);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(27, 13);
            this.label3.TabIndex = 101;
            this.label3.Text = "Max";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(72, 10);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 13);
            this.label2.TabIndex = 97;
            this.label2.Text = "Pokémon :";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // pl1_4
            // 
            this.pl1_4.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.pl1_4.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.pl1_4.DisplayMember = "Name";
            this.pl1_4.DropDownHeight = 140;
            this.pl1_4.DropDownWidth = 150;
            this.pl1_4.FormattingEnabled = true;
            this.pl1_4.IntegralHeight = false;
            this.pl1_4.Location = new System.Drawing.Point(75, 98);
            this.pl1_4.Name = "pl1_4";
            this.pl1_4.Size = new System.Drawing.Size(119, 21);
            this.pl1_4.TabIndex = 100;
            this.pl1_4.ValueMember = "Value";
            // 
            // pl1_1
            // 
            this.pl1_1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.pl1_1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.pl1_1.DisplayMember = "Name";
            this.pl1_1.DropDownHeight = 140;
            this.pl1_1.DropDownWidth = 150;
            this.pl1_1.FormattingEnabled = true;
            this.pl1_1.IntegralHeight = false;
            this.pl1_1.Location = new System.Drawing.Point(75, 26);
            this.pl1_1.Name = "pl1_1";
            this.pl1_1.Size = new System.Drawing.Size(119, 21);
            this.pl1_1.TabIndex = 96;
            this.pl1_1.ValueMember = "Value";
            // 
            // pl1_3
            // 
            this.pl1_3.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.pl1_3.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.pl1_3.DisplayMember = "Name";
            this.pl1_3.DropDownHeight = 140;
            this.pl1_3.DropDownWidth = 150;
            this.pl1_3.FormattingEnabled = true;
            this.pl1_3.IntegralHeight = false;
            this.pl1_3.Location = new System.Drawing.Point(75, 74);
            this.pl1_3.Name = "pl1_3";
            this.pl1_3.Size = new System.Drawing.Size(119, 21);
            this.pl1_3.TabIndex = 99;
            this.pl1_3.ValueMember = "Value";
            // 
            // pl1_2
            // 
            this.pl1_2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.pl1_2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.pl1_2.DisplayMember = "Name";
            this.pl1_2.DropDownHeight = 140;
            this.pl1_2.DropDownWidth = 150;
            this.pl1_2.FormattingEnabled = true;
            this.pl1_2.IntegralHeight = false;
            this.pl1_2.Location = new System.Drawing.Point(75, 50);
            this.pl1_2.Name = "pl1_2";
            this.pl1_2.Size = new System.Drawing.Size(119, 21);
            this.pl1_2.TabIndex = 98;
            this.pl1_2.ValueMember = "Value";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox11);
            this.tabPage2.Controls.Add(this.label57);
            this.tabPage2.Controls.Add(this.label49);
            this.tabPage2.Controls.Add(this.label42);
            this.tabPage2.Controls.Add(this.groupBox9);
            this.tabPage2.Controls.Add(this.label40);
            this.tabPage2.Controls.Add(this.groupBox8);
            this.tabPage2.Controls.Add(this.groupBox7);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Size = new System.Drawing.Size(572, 443);
            this.tabPage2.TabIndex = 5;
            this.tabPage2.Text = "Pokémon B2";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.button5);
            this.groupBox11.Controls.Add(this.button7);
            this.groupBox11.Location = new System.Drawing.Point(23, 388);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(200, 39);
            this.groupBox11.TabIndex = 165;
            this.groupBox11.TabStop = false;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(6, 11);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(108, 23);
            this.button5.TabIndex = 162;
            this.button5.Text = "< Copy to W2 list";
            this.button5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button5.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(119, 11);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(75, 23);
            this.button7.TabIndex = 163;
            this.button7.Text = "Swap";
            this.button7.UseVisualStyleBackColor = true;
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(407, 394);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(159, 13);
            this.label57.TabIndex = 164;
            this.label57.Text = "[!] = need edit overworld texture.\r\n";
            this.toolTip1.SetToolTip(this.label57, "pokemon with [!] mark and if pokemon just have 1 forme \r\n(if you change forme val" +
        "ue into >0) it will become blue man sprite.");
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(-1, 314);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(36, 26);
            this.label49.TabIndex = 161;
            this.label49.Text = "C\r\n(15 %)";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(-1, 184);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(30, 26);
            this.label42.TabIndex = 161;
            this.label42.Text = "B\r\n(4 %)";
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.pbx_pl6_4);
            this.groupBox9.Controls.Add(this.pbx_pl6_3);
            this.groupBox9.Controls.Add(this.pbx_pl6_2);
            this.groupBox9.Controls.Add(this.pbx_pl6_1);
            this.groupBox9.Controls.Add(this.label50);
            this.groupBox9.Controls.Add(this.label51);
            this.groupBox9.Controls.Add(this.unk6_6);
            this.groupBox9.Controls.Add(this.unk6_5);
            this.groupBox9.Controls.Add(this.unk6_4);
            this.groupBox9.Controls.Add(this.unk6_3);
            this.groupBox9.Controls.Add(this.unk6_2);
            this.groupBox9.Controls.Add(this.unk6_1);
            this.groupBox9.Controls.Add(this.label52);
            this.groupBox9.Controls.Add(this.fr6_4);
            this.groupBox9.Controls.Add(this.fr6_3);
            this.groupBox9.Controls.Add(this.fr6_2);
            this.groupBox9.Controls.Add(this.fr6_1);
            this.groupBox9.Controls.Add(this.mn6_4);
            this.groupBox9.Controls.Add(this.mn6_3);
            this.groupBox9.Controls.Add(this.mn6_2);
            this.groupBox9.Controls.Add(this.mn6_1);
            this.groupBox9.Controls.Add(this.label53);
            this.groupBox9.Controls.Add(this.mx6_4);
            this.groupBox9.Controls.Add(this.mx6_3);
            this.groupBox9.Controls.Add(this.mx6_2);
            this.groupBox9.Controls.Add(this.mx6_1);
            this.groupBox9.Controls.Add(this.label54);
            this.groupBox9.Controls.Add(this.label55);
            this.groupBox9.Controls.Add(this.pl6_4);
            this.groupBox9.Controls.Add(this.pl6_1);
            this.groupBox9.Controls.Add(this.pl6_3);
            this.groupBox9.Controls.Add(this.pl6_2);
            this.groupBox9.Location = new System.Drawing.Point(23, 260);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(543, 128);
            this.groupBox9.TabIndex = 160;
            this.groupBox9.TabStop = false;
            // 
            // pbx_pl6_4
            // 
            this.pbx_pl6_4.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pbx_pl6_4.ErrorImage")));
            this.pbx_pl6_4.ImageLocation = "";
            this.pbx_pl6_4.InitialImage = ((System.Drawing.Image)(resources.GetObject("pbx_pl6_4.InitialImage")));
            this.pbx_pl6_4.Location = new System.Drawing.Point(10, 87);
            this.pbx_pl6_4.Margin = new System.Windows.Forms.Padding(0);
            this.pbx_pl6_4.Name = "pbx_pl6_4";
            this.pbx_pl6_4.Size = new System.Drawing.Size(29, 33);
            this.pbx_pl6_4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pbx_pl6_4.TabIndex = 159;
            this.pbx_pl6_4.TabStop = false;
            // 
            // pbx_pl6_3
            // 
            this.pbx_pl6_3.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pbx_pl6_3.ErrorImage")));
            this.pbx_pl6_3.ImageLocation = "";
            this.pbx_pl6_3.InitialImage = ((System.Drawing.Image)(resources.GetObject("pbx_pl6_3.InitialImage")));
            this.pbx_pl6_3.Location = new System.Drawing.Point(39, 63);
            this.pbx_pl6_3.Margin = new System.Windows.Forms.Padding(0);
            this.pbx_pl6_3.Name = "pbx_pl6_3";
            this.pbx_pl6_3.Size = new System.Drawing.Size(29, 33);
            this.pbx_pl6_3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pbx_pl6_3.TabIndex = 158;
            this.pbx_pl6_3.TabStop = false;
            // 
            // pbx_pl6_2
            // 
            this.pbx_pl6_2.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pbx_pl6_2.ErrorImage")));
            this.pbx_pl6_2.ImageLocation = "";
            this.pbx_pl6_2.InitialImage = ((System.Drawing.Image)(resources.GetObject("pbx_pl6_2.InitialImage")));
            this.pbx_pl6_2.Location = new System.Drawing.Point(10, 39);
            this.pbx_pl6_2.Margin = new System.Windows.Forms.Padding(0);
            this.pbx_pl6_2.Name = "pbx_pl6_2";
            this.pbx_pl6_2.Size = new System.Drawing.Size(29, 33);
            this.pbx_pl6_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pbx_pl6_2.TabIndex = 157;
            this.pbx_pl6_2.TabStop = false;
            // 
            // pbx_pl6_1
            // 
            this.pbx_pl6_1.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pbx_pl6_1.ErrorImage")));
            this.pbx_pl6_1.ImageLocation = "";
            this.pbx_pl6_1.InitialImage = ((System.Drawing.Image)(resources.GetObject("pbx_pl6_1.InitialImage")));
            this.pbx_pl6_1.Location = new System.Drawing.Point(39, 15);
            this.pbx_pl6_1.Margin = new System.Windows.Forms.Padding(0);
            this.pbx_pl6_1.Name = "pbx_pl6_1";
            this.pbx_pl6_1.Size = new System.Drawing.Size(29, 33);
            this.pbx_pl6_1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pbx_pl6_1.TabIndex = 156;
            this.pbx_pl6_1.TabStop = false;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(463, 10);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(13, 13);
            this.label50.TabIndex = 151;
            this.label50.Text = "?";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(397, 10);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(33, 13);
            this.label51.TabIndex = 150;
            this.label51.Text = "forme";
            // 
            // unk6_6
            // 
            this.unk6_6.Enabled = false;
            this.unk6_6.Location = new System.Drawing.Point(466, 51);
            this.unk6_6.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.unk6_6.Name = "unk6_6";
            this.unk6_6.Size = new System.Drawing.Size(70, 20);
            this.unk6_6.TabIndex = 148;
            // 
            // unk6_5
            // 
            this.unk6_5.Enabled = false;
            this.unk6_5.Location = new System.Drawing.Point(466, 26);
            this.unk6_5.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.unk6_5.Name = "unk6_5";
            this.unk6_5.Size = new System.Drawing.Size(70, 20);
            this.unk6_5.TabIndex = 147;
            // 
            // unk6_4
            // 
            this.unk6_4.Location = new System.Drawing.Point(400, 99);
            this.unk6_4.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.unk6_4.Name = "unk6_4";
            this.unk6_4.Size = new System.Drawing.Size(57, 20);
            this.unk6_4.TabIndex = 146;
            // 
            // unk6_3
            // 
            this.unk6_3.Location = new System.Drawing.Point(400, 75);
            this.unk6_3.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.unk6_3.Name = "unk6_3";
            this.unk6_3.Size = new System.Drawing.Size(57, 20);
            this.unk6_3.TabIndex = 145;
            // 
            // unk6_2
            // 
            this.unk6_2.Location = new System.Drawing.Point(400, 51);
            this.unk6_2.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.unk6_2.Name = "unk6_2";
            this.unk6_2.Size = new System.Drawing.Size(57, 20);
            this.unk6_2.TabIndex = 144;
            // 
            // unk6_1
            // 
            this.unk6_1.Location = new System.Drawing.Point(400, 27);
            this.unk6_1.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.unk6_1.Name = "unk6_1";
            this.unk6_1.Size = new System.Drawing.Size(57, 20);
            this.unk6_1.TabIndex = 149;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(331, 11);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(49, 13);
            this.label52.TabIndex = 143;
            this.label52.Text = "% female";
            this.label52.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // fr6_4
            // 
            this.fr6_4.Location = new System.Drawing.Point(334, 99);
            this.fr6_4.Name = "fr6_4";
            this.fr6_4.Size = new System.Drawing.Size(49, 20);
            this.fr6_4.TabIndex = 142;
            // 
            // fr6_3
            // 
            this.fr6_3.Location = new System.Drawing.Point(334, 74);
            this.fr6_3.Name = "fr6_3";
            this.fr6_3.Size = new System.Drawing.Size(49, 20);
            this.fr6_3.TabIndex = 141;
            // 
            // fr6_2
            // 
            this.fr6_2.Location = new System.Drawing.Point(334, 50);
            this.fr6_2.Name = "fr6_2";
            this.fr6_2.Size = new System.Drawing.Size(49, 20);
            this.fr6_2.TabIndex = 140;
            // 
            // fr6_1
            // 
            this.fr6_1.Location = new System.Drawing.Point(334, 27);
            this.fr6_1.Name = "fr6_1";
            this.fr6_1.Size = new System.Drawing.Size(49, 20);
            this.fr6_1.TabIndex = 139;
            // 
            // mn6_4
            // 
            this.mn6_4.Location = new System.Drawing.Point(282, 98);
            this.mn6_4.Name = "mn6_4";
            this.mn6_4.Size = new System.Drawing.Size(46, 20);
            this.mn6_4.TabIndex = 138;
            // 
            // mn6_3
            // 
            this.mn6_3.Location = new System.Drawing.Point(282, 74);
            this.mn6_3.Name = "mn6_3";
            this.mn6_3.Size = new System.Drawing.Size(46, 20);
            this.mn6_3.TabIndex = 137;
            // 
            // mn6_2
            // 
            this.mn6_2.Location = new System.Drawing.Point(282, 50);
            this.mn6_2.Name = "mn6_2";
            this.mn6_2.Size = new System.Drawing.Size(46, 20);
            this.mn6_2.TabIndex = 136;
            // 
            // mn6_1
            // 
            this.mn6_1.Location = new System.Drawing.Point(282, 26);
            this.mn6_1.Name = "mn6_1";
            this.mn6_1.Size = new System.Drawing.Size(46, 20);
            this.mn6_1.TabIndex = 135;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(279, 10);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(24, 13);
            this.label53.TabIndex = 134;
            this.label53.Text = "Min";
            this.label53.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // mx6_4
            // 
            this.mx6_4.Location = new System.Drawing.Point(230, 98);
            this.mx6_4.Name = "mx6_4";
            this.mx6_4.Size = new System.Drawing.Size(46, 20);
            this.mx6_4.TabIndex = 133;
            // 
            // mx6_3
            // 
            this.mx6_3.Location = new System.Drawing.Point(230, 74);
            this.mx6_3.Name = "mx6_3";
            this.mx6_3.Size = new System.Drawing.Size(46, 20);
            this.mx6_3.TabIndex = 132;
            // 
            // mx6_2
            // 
            this.mx6_2.Location = new System.Drawing.Point(230, 50);
            this.mx6_2.Name = "mx6_2";
            this.mx6_2.Size = new System.Drawing.Size(46, 20);
            this.mx6_2.TabIndex = 131;
            // 
            // mx6_1
            // 
            this.mx6_1.Location = new System.Drawing.Point(230, 26);
            this.mx6_1.Name = "mx6_1";
            this.mx6_1.Size = new System.Drawing.Size(46, 20);
            this.mx6_1.TabIndex = 130;
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(227, 10);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(27, 13);
            this.label54.TabIndex = 129;
            this.label54.Text = "Max";
            this.label54.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(72, 11);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(58, 13);
            this.label55.TabIndex = 125;
            this.label55.Text = "Pokémon :";
            this.label55.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // pl6_4
            // 
            this.pl6_4.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.pl6_4.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.pl6_4.DisplayMember = "Name";
            this.pl6_4.DropDownHeight = 140;
            this.pl6_4.DropDownWidth = 150;
            this.pl6_4.FormattingEnabled = true;
            this.pl6_4.IntegralHeight = false;
            this.pl6_4.Location = new System.Drawing.Point(75, 99);
            this.pl6_4.Name = "pl6_4";
            this.pl6_4.Size = new System.Drawing.Size(119, 21);
            this.pl6_4.TabIndex = 128;
            this.pl6_4.ValueMember = "Value";
            // 
            // pl6_1
            // 
            this.pl6_1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.pl6_1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.pl6_1.DisplayMember = "Name";
            this.pl6_1.DropDownHeight = 140;
            this.pl6_1.DropDownWidth = 150;
            this.pl6_1.FormattingEnabled = true;
            this.pl6_1.IntegralHeight = false;
            this.pl6_1.Location = new System.Drawing.Point(75, 27);
            this.pl6_1.Name = "pl6_1";
            this.pl6_1.Size = new System.Drawing.Size(119, 21);
            this.pl6_1.TabIndex = 124;
            this.pl6_1.ValueMember = "Value";
            // 
            // pl6_3
            // 
            this.pl6_3.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.pl6_3.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.pl6_3.DisplayMember = "Name";
            this.pl6_3.DropDownHeight = 140;
            this.pl6_3.DropDownWidth = 150;
            this.pl6_3.FormattingEnabled = true;
            this.pl6_3.IntegralHeight = false;
            this.pl6_3.Location = new System.Drawing.Point(75, 75);
            this.pl6_3.Name = "pl6_3";
            this.pl6_3.Size = new System.Drawing.Size(119, 21);
            this.pl6_3.TabIndex = 127;
            this.pl6_3.ValueMember = "Value";
            // 
            // pl6_2
            // 
            this.pl6_2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.pl6_2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.pl6_2.DisplayMember = "Name";
            this.pl6_2.DropDownHeight = 140;
            this.pl6_2.DropDownWidth = 150;
            this.pl6_2.FormattingEnabled = true;
            this.pl6_2.IntegralHeight = false;
            this.pl6_2.Location = new System.Drawing.Point(75, 51);
            this.pl6_2.Name = "pl6_2";
            this.pl6_2.Size = new System.Drawing.Size(119, 21);
            this.pl6_2.TabIndex = 126;
            this.pl6_2.ValueMember = "Value";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(-1, 54);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(30, 26);
            this.label40.TabIndex = 157;
            this.label40.Text = "A\r\n(1 %)";
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.pbx_pl5_4);
            this.groupBox8.Controls.Add(this.pbx_pl5_3);
            this.groupBox8.Controls.Add(this.pbx_pl5_2);
            this.groupBox8.Controls.Add(this.pbx_pl5_1);
            this.groupBox8.Controls.Add(this.label43);
            this.groupBox8.Controls.Add(this.label44);
            this.groupBox8.Controls.Add(this.unk5_6);
            this.groupBox8.Controls.Add(this.unk5_5);
            this.groupBox8.Controls.Add(this.unk5_4);
            this.groupBox8.Controls.Add(this.unk5_3);
            this.groupBox8.Controls.Add(this.unk5_2);
            this.groupBox8.Controls.Add(this.unk5_1);
            this.groupBox8.Controls.Add(this.label45);
            this.groupBox8.Controls.Add(this.fr5_4);
            this.groupBox8.Controls.Add(this.fr5_3);
            this.groupBox8.Controls.Add(this.fr5_2);
            this.groupBox8.Controls.Add(this.fr5_1);
            this.groupBox8.Controls.Add(this.mn5_4);
            this.groupBox8.Controls.Add(this.mn5_3);
            this.groupBox8.Controls.Add(this.mn5_2);
            this.groupBox8.Controls.Add(this.mn5_1);
            this.groupBox8.Controls.Add(this.label46);
            this.groupBox8.Controls.Add(this.mx5_4);
            this.groupBox8.Controls.Add(this.mx5_3);
            this.groupBox8.Controls.Add(this.mx5_2);
            this.groupBox8.Controls.Add(this.mx5_1);
            this.groupBox8.Controls.Add(this.label47);
            this.groupBox8.Controls.Add(this.label48);
            this.groupBox8.Controls.Add(this.pl5_4);
            this.groupBox8.Controls.Add(this.pl5_1);
            this.groupBox8.Controls.Add(this.pl5_3);
            this.groupBox8.Controls.Add(this.pl5_2);
            this.groupBox8.Location = new System.Drawing.Point(23, 130);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(543, 128);
            this.groupBox8.TabIndex = 160;
            this.groupBox8.TabStop = false;
            // 
            // pbx_pl5_4
            // 
            this.pbx_pl5_4.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pbx_pl5_4.ErrorImage")));
            this.pbx_pl5_4.ImageLocation = "";
            this.pbx_pl5_4.InitialImage = ((System.Drawing.Image)(resources.GetObject("pbx_pl5_4.InitialImage")));
            this.pbx_pl5_4.Location = new System.Drawing.Point(10, 87);
            this.pbx_pl5_4.Margin = new System.Windows.Forms.Padding(0);
            this.pbx_pl5_4.Name = "pbx_pl5_4";
            this.pbx_pl5_4.Size = new System.Drawing.Size(29, 33);
            this.pbx_pl5_4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pbx_pl5_4.TabIndex = 159;
            this.pbx_pl5_4.TabStop = false;
            // 
            // pbx_pl5_3
            // 
            this.pbx_pl5_3.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pbx_pl5_3.ErrorImage")));
            this.pbx_pl5_3.ImageLocation = "";
            this.pbx_pl5_3.InitialImage = ((System.Drawing.Image)(resources.GetObject("pbx_pl5_3.InitialImage")));
            this.pbx_pl5_3.Location = new System.Drawing.Point(39, 63);
            this.pbx_pl5_3.Margin = new System.Windows.Forms.Padding(0);
            this.pbx_pl5_3.Name = "pbx_pl5_3";
            this.pbx_pl5_3.Size = new System.Drawing.Size(29, 33);
            this.pbx_pl5_3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pbx_pl5_3.TabIndex = 158;
            this.pbx_pl5_3.TabStop = false;
            // 
            // pbx_pl5_2
            // 
            this.pbx_pl5_2.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pbx_pl5_2.ErrorImage")));
            this.pbx_pl5_2.ImageLocation = "";
            this.pbx_pl5_2.InitialImage = ((System.Drawing.Image)(resources.GetObject("pbx_pl5_2.InitialImage")));
            this.pbx_pl5_2.Location = new System.Drawing.Point(10, 39);
            this.pbx_pl5_2.Margin = new System.Windows.Forms.Padding(0);
            this.pbx_pl5_2.Name = "pbx_pl5_2";
            this.pbx_pl5_2.Size = new System.Drawing.Size(29, 33);
            this.pbx_pl5_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pbx_pl5_2.TabIndex = 157;
            this.pbx_pl5_2.TabStop = false;
            // 
            // pbx_pl5_1
            // 
            this.pbx_pl5_1.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pbx_pl5_1.ErrorImage")));
            this.pbx_pl5_1.ImageLocation = "";
            this.pbx_pl5_1.InitialImage = ((System.Drawing.Image)(resources.GetObject("pbx_pl5_1.InitialImage")));
            this.pbx_pl5_1.Location = new System.Drawing.Point(39, 15);
            this.pbx_pl5_1.Margin = new System.Windows.Forms.Padding(0);
            this.pbx_pl5_1.Name = "pbx_pl5_1";
            this.pbx_pl5_1.Size = new System.Drawing.Size(29, 33);
            this.pbx_pl5_1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pbx_pl5_1.TabIndex = 156;
            this.pbx_pl5_1.TabStop = false;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(463, 10);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(13, 13);
            this.label43.TabIndex = 151;
            this.label43.Text = "?";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(397, 10);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(33, 13);
            this.label44.TabIndex = 150;
            this.label44.Text = "forme";
            // 
            // unk5_6
            // 
            this.unk5_6.Enabled = false;
            this.unk5_6.Location = new System.Drawing.Point(466, 51);
            this.unk5_6.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.unk5_6.Name = "unk5_6";
            this.unk5_6.Size = new System.Drawing.Size(70, 20);
            this.unk5_6.TabIndex = 148;
            // 
            // unk5_5
            // 
            this.unk5_5.Enabled = false;
            this.unk5_5.Location = new System.Drawing.Point(466, 26);
            this.unk5_5.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.unk5_5.Name = "unk5_5";
            this.unk5_5.Size = new System.Drawing.Size(70, 20);
            this.unk5_5.TabIndex = 147;
            // 
            // unk5_4
            // 
            this.unk5_4.Location = new System.Drawing.Point(400, 99);
            this.unk5_4.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.unk5_4.Name = "unk5_4";
            this.unk5_4.Size = new System.Drawing.Size(57, 20);
            this.unk5_4.TabIndex = 146;
            // 
            // unk5_3
            // 
            this.unk5_3.Location = new System.Drawing.Point(400, 75);
            this.unk5_3.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.unk5_3.Name = "unk5_3";
            this.unk5_3.Size = new System.Drawing.Size(57, 20);
            this.unk5_3.TabIndex = 145;
            // 
            // unk5_2
            // 
            this.unk5_2.Location = new System.Drawing.Point(400, 51);
            this.unk5_2.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.unk5_2.Name = "unk5_2";
            this.unk5_2.Size = new System.Drawing.Size(57, 20);
            this.unk5_2.TabIndex = 144;
            // 
            // unk5_1
            // 
            this.unk5_1.Location = new System.Drawing.Point(400, 27);
            this.unk5_1.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.unk5_1.Name = "unk5_1";
            this.unk5_1.Size = new System.Drawing.Size(57, 20);
            this.unk5_1.TabIndex = 149;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(331, 11);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(49, 13);
            this.label45.TabIndex = 143;
            this.label45.Text = "% female";
            this.label45.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // fr5_4
            // 
            this.fr5_4.Location = new System.Drawing.Point(334, 99);
            this.fr5_4.Name = "fr5_4";
            this.fr5_4.Size = new System.Drawing.Size(49, 20);
            this.fr5_4.TabIndex = 142;
            // 
            // fr5_3
            // 
            this.fr5_3.Location = new System.Drawing.Point(334, 74);
            this.fr5_3.Name = "fr5_3";
            this.fr5_3.Size = new System.Drawing.Size(49, 20);
            this.fr5_3.TabIndex = 141;
            // 
            // fr5_2
            // 
            this.fr5_2.Location = new System.Drawing.Point(334, 50);
            this.fr5_2.Name = "fr5_2";
            this.fr5_2.Size = new System.Drawing.Size(49, 20);
            this.fr5_2.TabIndex = 140;
            // 
            // fr5_1
            // 
            this.fr5_1.Location = new System.Drawing.Point(334, 27);
            this.fr5_1.Name = "fr5_1";
            this.fr5_1.Size = new System.Drawing.Size(49, 20);
            this.fr5_1.TabIndex = 139;
            // 
            // mn5_4
            // 
            this.mn5_4.Location = new System.Drawing.Point(282, 98);
            this.mn5_4.Name = "mn5_4";
            this.mn5_4.Size = new System.Drawing.Size(46, 20);
            this.mn5_4.TabIndex = 138;
            // 
            // mn5_3
            // 
            this.mn5_3.Location = new System.Drawing.Point(282, 74);
            this.mn5_3.Name = "mn5_3";
            this.mn5_3.Size = new System.Drawing.Size(46, 20);
            this.mn5_3.TabIndex = 137;
            // 
            // mn5_2
            // 
            this.mn5_2.Location = new System.Drawing.Point(282, 50);
            this.mn5_2.Name = "mn5_2";
            this.mn5_2.Size = new System.Drawing.Size(46, 20);
            this.mn5_2.TabIndex = 136;
            // 
            // mn5_1
            // 
            this.mn5_1.Location = new System.Drawing.Point(282, 26);
            this.mn5_1.Name = "mn5_1";
            this.mn5_1.Size = new System.Drawing.Size(46, 20);
            this.mn5_1.TabIndex = 135;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(279, 10);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(24, 13);
            this.label46.TabIndex = 134;
            this.label46.Text = "Min";
            this.label46.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // mx5_4
            // 
            this.mx5_4.Location = new System.Drawing.Point(230, 98);
            this.mx5_4.Name = "mx5_4";
            this.mx5_4.Size = new System.Drawing.Size(46, 20);
            this.mx5_4.TabIndex = 133;
            // 
            // mx5_3
            // 
            this.mx5_3.Location = new System.Drawing.Point(230, 74);
            this.mx5_3.Name = "mx5_3";
            this.mx5_3.Size = new System.Drawing.Size(46, 20);
            this.mx5_3.TabIndex = 132;
            // 
            // mx5_2
            // 
            this.mx5_2.Location = new System.Drawing.Point(230, 50);
            this.mx5_2.Name = "mx5_2";
            this.mx5_2.Size = new System.Drawing.Size(46, 20);
            this.mx5_2.TabIndex = 131;
            // 
            // mx5_1
            // 
            this.mx5_1.Location = new System.Drawing.Point(230, 26);
            this.mx5_1.Name = "mx5_1";
            this.mx5_1.Size = new System.Drawing.Size(46, 20);
            this.mx5_1.TabIndex = 130;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(227, 10);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(27, 13);
            this.label47.TabIndex = 129;
            this.label47.Text = "Max";
            this.label47.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(72, 11);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(58, 13);
            this.label48.TabIndex = 125;
            this.label48.Text = "Pokémon :";
            this.label48.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // pl5_4
            // 
            this.pl5_4.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.pl5_4.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.pl5_4.DisplayMember = "Name";
            this.pl5_4.DropDownHeight = 140;
            this.pl5_4.DropDownWidth = 150;
            this.pl5_4.FormattingEnabled = true;
            this.pl5_4.IntegralHeight = false;
            this.pl5_4.Location = new System.Drawing.Point(75, 99);
            this.pl5_4.Name = "pl5_4";
            this.pl5_4.Size = new System.Drawing.Size(119, 21);
            this.pl5_4.TabIndex = 128;
            this.pl5_4.ValueMember = "Value";
            // 
            // pl5_1
            // 
            this.pl5_1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.pl5_1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.pl5_1.DisplayMember = "Name";
            this.pl5_1.DropDownHeight = 140;
            this.pl5_1.DropDownWidth = 150;
            this.pl5_1.FormattingEnabled = true;
            this.pl5_1.IntegralHeight = false;
            this.pl5_1.Location = new System.Drawing.Point(75, 27);
            this.pl5_1.Name = "pl5_1";
            this.pl5_1.Size = new System.Drawing.Size(119, 21);
            this.pl5_1.TabIndex = 124;
            this.pl5_1.ValueMember = "Value";
            // 
            // pl5_3
            // 
            this.pl5_3.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.pl5_3.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.pl5_3.DisplayMember = "Name";
            this.pl5_3.DropDownHeight = 140;
            this.pl5_3.DropDownWidth = 150;
            this.pl5_3.FormattingEnabled = true;
            this.pl5_3.IntegralHeight = false;
            this.pl5_3.Location = new System.Drawing.Point(75, 75);
            this.pl5_3.Name = "pl5_3";
            this.pl5_3.Size = new System.Drawing.Size(119, 21);
            this.pl5_3.TabIndex = 127;
            this.pl5_3.ValueMember = "Value";
            // 
            // pl5_2
            // 
            this.pl5_2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.pl5_2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.pl5_2.DisplayMember = "Name";
            this.pl5_2.DropDownHeight = 140;
            this.pl5_2.DropDownWidth = 150;
            this.pl5_2.FormattingEnabled = true;
            this.pl5_2.IntegralHeight = false;
            this.pl5_2.Location = new System.Drawing.Point(75, 51);
            this.pl5_2.Name = "pl5_2";
            this.pl5_2.Size = new System.Drawing.Size(119, 21);
            this.pl5_2.TabIndex = 126;
            this.pl5_2.ValueMember = "Value";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.pbx_pl4_4);
            this.groupBox7.Controls.Add(this.pbx_pl4_3);
            this.groupBox7.Controls.Add(this.pbx_pl4_2);
            this.groupBox7.Controls.Add(this.pbx_pl4_1);
            this.groupBox7.Controls.Add(this.label10);
            this.groupBox7.Controls.Add(this.label11);
            this.groupBox7.Controls.Add(this.unk4_6);
            this.groupBox7.Controls.Add(this.unk4_5);
            this.groupBox7.Controls.Add(this.unk4_4);
            this.groupBox7.Controls.Add(this.unk4_3);
            this.groupBox7.Controls.Add(this.unk4_2);
            this.groupBox7.Controls.Add(this.unk4_1);
            this.groupBox7.Controls.Add(this.label12);
            this.groupBox7.Controls.Add(this.fr4_4);
            this.groupBox7.Controls.Add(this.fr4_3);
            this.groupBox7.Controls.Add(this.fr4_2);
            this.groupBox7.Controls.Add(this.fr4_1);
            this.groupBox7.Controls.Add(this.mn4_4);
            this.groupBox7.Controls.Add(this.mn4_3);
            this.groupBox7.Controls.Add(this.mn4_2);
            this.groupBox7.Controls.Add(this.mn4_1);
            this.groupBox7.Controls.Add(this.label13);
            this.groupBox7.Controls.Add(this.mx4_4);
            this.groupBox7.Controls.Add(this.mx4_3);
            this.groupBox7.Controls.Add(this.mx4_2);
            this.groupBox7.Controls.Add(this.mx4_1);
            this.groupBox7.Controls.Add(this.label14);
            this.groupBox7.Controls.Add(this.label25);
            this.groupBox7.Controls.Add(this.pl4_4);
            this.groupBox7.Controls.Add(this.pl4_1);
            this.groupBox7.Controls.Add(this.pl4_3);
            this.groupBox7.Controls.Add(this.pl4_2);
            this.groupBox7.Location = new System.Drawing.Point(23, 0);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(543, 128);
            this.groupBox7.TabIndex = 156;
            this.groupBox7.TabStop = false;
            // 
            // pbx_pl4_4
            // 
            this.pbx_pl4_4.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pbx_pl4_4.ErrorImage")));
            this.pbx_pl4_4.ImageLocation = "";
            this.pbx_pl4_4.InitialImage = ((System.Drawing.Image)(resources.GetObject("pbx_pl4_4.InitialImage")));
            this.pbx_pl4_4.Location = new System.Drawing.Point(10, 87);
            this.pbx_pl4_4.Margin = new System.Windows.Forms.Padding(0);
            this.pbx_pl4_4.Name = "pbx_pl4_4";
            this.pbx_pl4_4.Size = new System.Drawing.Size(29, 33);
            this.pbx_pl4_4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pbx_pl4_4.TabIndex = 159;
            this.pbx_pl4_4.TabStop = false;
            // 
            // pbx_pl4_3
            // 
            this.pbx_pl4_3.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pbx_pl4_3.ErrorImage")));
            this.pbx_pl4_3.ImageLocation = "";
            this.pbx_pl4_3.InitialImage = ((System.Drawing.Image)(resources.GetObject("pbx_pl4_3.InitialImage")));
            this.pbx_pl4_3.Location = new System.Drawing.Point(39, 63);
            this.pbx_pl4_3.Margin = new System.Windows.Forms.Padding(0);
            this.pbx_pl4_3.Name = "pbx_pl4_3";
            this.pbx_pl4_3.Size = new System.Drawing.Size(29, 33);
            this.pbx_pl4_3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pbx_pl4_3.TabIndex = 158;
            this.pbx_pl4_3.TabStop = false;
            // 
            // pbx_pl4_2
            // 
            this.pbx_pl4_2.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pbx_pl4_2.ErrorImage")));
            this.pbx_pl4_2.ImageLocation = "";
            this.pbx_pl4_2.InitialImage = ((System.Drawing.Image)(resources.GetObject("pbx_pl4_2.InitialImage")));
            this.pbx_pl4_2.Location = new System.Drawing.Point(10, 39);
            this.pbx_pl4_2.Margin = new System.Windows.Forms.Padding(0);
            this.pbx_pl4_2.Name = "pbx_pl4_2";
            this.pbx_pl4_2.Size = new System.Drawing.Size(29, 33);
            this.pbx_pl4_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pbx_pl4_2.TabIndex = 157;
            this.pbx_pl4_2.TabStop = false;
            // 
            // pbx_pl4_1
            // 
            this.pbx_pl4_1.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pbx_pl4_1.ErrorImage")));
            this.pbx_pl4_1.ImageLocation = "";
            this.pbx_pl4_1.InitialImage = ((System.Drawing.Image)(resources.GetObject("pbx_pl4_1.InitialImage")));
            this.pbx_pl4_1.Location = new System.Drawing.Point(39, 15);
            this.pbx_pl4_1.Margin = new System.Windows.Forms.Padding(0);
            this.pbx_pl4_1.Name = "pbx_pl4_1";
            this.pbx_pl4_1.Size = new System.Drawing.Size(29, 33);
            this.pbx_pl4_1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pbx_pl4_1.TabIndex = 156;
            this.pbx_pl4_1.TabStop = false;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(463, 10);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(13, 13);
            this.label10.TabIndex = 151;
            this.label10.Text = "?";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(397, 10);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(33, 13);
            this.label11.TabIndex = 150;
            this.label11.Text = "forme";
            // 
            // unk4_6
            // 
            this.unk4_6.Enabled = false;
            this.unk4_6.Location = new System.Drawing.Point(466, 51);
            this.unk4_6.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.unk4_6.Name = "unk4_6";
            this.unk4_6.Size = new System.Drawing.Size(70, 20);
            this.unk4_6.TabIndex = 148;
            // 
            // unk4_5
            // 
            this.unk4_5.Enabled = false;
            this.unk4_5.Location = new System.Drawing.Point(466, 26);
            this.unk4_5.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.unk4_5.Name = "unk4_5";
            this.unk4_5.Size = new System.Drawing.Size(70, 20);
            this.unk4_5.TabIndex = 147;
            // 
            // unk4_4
            // 
            this.unk4_4.Location = new System.Drawing.Point(400, 99);
            this.unk4_4.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.unk4_4.Name = "unk4_4";
            this.unk4_4.Size = new System.Drawing.Size(57, 20);
            this.unk4_4.TabIndex = 146;
            // 
            // unk4_3
            // 
            this.unk4_3.Location = new System.Drawing.Point(400, 75);
            this.unk4_3.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.unk4_3.Name = "unk4_3";
            this.unk4_3.Size = new System.Drawing.Size(57, 20);
            this.unk4_3.TabIndex = 145;
            // 
            // unk4_2
            // 
            this.unk4_2.Location = new System.Drawing.Point(400, 51);
            this.unk4_2.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.unk4_2.Name = "unk4_2";
            this.unk4_2.Size = new System.Drawing.Size(57, 20);
            this.unk4_2.TabIndex = 144;
            // 
            // unk4_1
            // 
            this.unk4_1.Location = new System.Drawing.Point(400, 27);
            this.unk4_1.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.unk4_1.Name = "unk4_1";
            this.unk4_1.Size = new System.Drawing.Size(57, 20);
            this.unk4_1.TabIndex = 149;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(331, 11);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(49, 13);
            this.label12.TabIndex = 143;
            this.label12.Text = "% female";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // fr4_4
            // 
            this.fr4_4.Location = new System.Drawing.Point(334, 99);
            this.fr4_4.Name = "fr4_4";
            this.fr4_4.Size = new System.Drawing.Size(49, 20);
            this.fr4_4.TabIndex = 142;
            // 
            // fr4_3
            // 
            this.fr4_3.Location = new System.Drawing.Point(334, 74);
            this.fr4_3.Name = "fr4_3";
            this.fr4_3.Size = new System.Drawing.Size(49, 20);
            this.fr4_3.TabIndex = 141;
            // 
            // fr4_2
            // 
            this.fr4_2.Location = new System.Drawing.Point(334, 50);
            this.fr4_2.Name = "fr4_2";
            this.fr4_2.Size = new System.Drawing.Size(49, 20);
            this.fr4_2.TabIndex = 140;
            // 
            // fr4_1
            // 
            this.fr4_1.Location = new System.Drawing.Point(334, 27);
            this.fr4_1.Name = "fr4_1";
            this.fr4_1.Size = new System.Drawing.Size(49, 20);
            this.fr4_1.TabIndex = 139;
            // 
            // mn4_4
            // 
            this.mn4_4.Location = new System.Drawing.Point(282, 98);
            this.mn4_4.Name = "mn4_4";
            this.mn4_4.Size = new System.Drawing.Size(46, 20);
            this.mn4_4.TabIndex = 138;
            // 
            // mn4_3
            // 
            this.mn4_3.Location = new System.Drawing.Point(282, 74);
            this.mn4_3.Name = "mn4_3";
            this.mn4_3.Size = new System.Drawing.Size(46, 20);
            this.mn4_3.TabIndex = 137;
            // 
            // mn4_2
            // 
            this.mn4_2.Location = new System.Drawing.Point(282, 50);
            this.mn4_2.Name = "mn4_2";
            this.mn4_2.Size = new System.Drawing.Size(46, 20);
            this.mn4_2.TabIndex = 136;
            // 
            // mn4_1
            // 
            this.mn4_1.Location = new System.Drawing.Point(282, 26);
            this.mn4_1.Name = "mn4_1";
            this.mn4_1.Size = new System.Drawing.Size(46, 20);
            this.mn4_1.TabIndex = 135;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(279, 10);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(24, 13);
            this.label13.TabIndex = 134;
            this.label13.Text = "Min";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // mx4_4
            // 
            this.mx4_4.Location = new System.Drawing.Point(230, 98);
            this.mx4_4.Name = "mx4_4";
            this.mx4_4.Size = new System.Drawing.Size(46, 20);
            this.mx4_4.TabIndex = 133;
            // 
            // mx4_3
            // 
            this.mx4_3.Location = new System.Drawing.Point(230, 74);
            this.mx4_3.Name = "mx4_3";
            this.mx4_3.Size = new System.Drawing.Size(46, 20);
            this.mx4_3.TabIndex = 132;
            // 
            // mx4_2
            // 
            this.mx4_2.Location = new System.Drawing.Point(230, 50);
            this.mx4_2.Name = "mx4_2";
            this.mx4_2.Size = new System.Drawing.Size(46, 20);
            this.mx4_2.TabIndex = 131;
            // 
            // mx4_1
            // 
            this.mx4_1.Location = new System.Drawing.Point(230, 26);
            this.mx4_1.Name = "mx4_1";
            this.mx4_1.Size = new System.Drawing.Size(46, 20);
            this.mx4_1.TabIndex = 130;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(227, 10);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(27, 13);
            this.label14.TabIndex = 129;
            this.label14.Text = "Max";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(72, 11);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(58, 13);
            this.label25.TabIndex = 125;
            this.label25.Text = "Pokémon :";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // pl4_4
            // 
            this.pl4_4.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.pl4_4.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.pl4_4.DisplayMember = "Name";
            this.pl4_4.DropDownHeight = 140;
            this.pl4_4.DropDownWidth = 150;
            this.pl4_4.FormattingEnabled = true;
            this.pl4_4.IntegralHeight = false;
            this.pl4_4.Location = new System.Drawing.Point(75, 99);
            this.pl4_4.Name = "pl4_4";
            this.pl4_4.Size = new System.Drawing.Size(119, 21);
            this.pl4_4.TabIndex = 128;
            this.pl4_4.ValueMember = "Value";
            // 
            // pl4_1
            // 
            this.pl4_1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.pl4_1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.pl4_1.DisplayMember = "Name";
            this.pl4_1.DropDownHeight = 140;
            this.pl4_1.DropDownWidth = 150;
            this.pl4_1.FormattingEnabled = true;
            this.pl4_1.IntegralHeight = false;
            this.pl4_1.Location = new System.Drawing.Point(75, 27);
            this.pl4_1.Name = "pl4_1";
            this.pl4_1.Size = new System.Drawing.Size(119, 21);
            this.pl4_1.TabIndex = 124;
            this.pl4_1.ValueMember = "Value";
            // 
            // pl4_3
            // 
            this.pl4_3.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.pl4_3.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.pl4_3.DisplayMember = "Name";
            this.pl4_3.DropDownHeight = 140;
            this.pl4_3.DropDownWidth = 150;
            this.pl4_3.FormattingEnabled = true;
            this.pl4_3.IntegralHeight = false;
            this.pl4_3.Location = new System.Drawing.Point(75, 75);
            this.pl4_3.Name = "pl4_3";
            this.pl4_3.Size = new System.Drawing.Size(119, 21);
            this.pl4_3.TabIndex = 127;
            this.pl4_3.ValueMember = "Value";
            // 
            // pl4_2
            // 
            this.pl4_2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.pl4_2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.pl4_2.DisplayMember = "Name";
            this.pl4_2.DropDownHeight = 140;
            this.pl4_2.DropDownWidth = 150;
            this.pl4_2.FormattingEnabled = true;
            this.pl4_2.IntegralHeight = false;
            this.pl4_2.Location = new System.Drawing.Point(75, 51);
            this.pl4_2.Name = "pl4_2";
            this.pl4_2.Size = new System.Drawing.Size(119, 21);
            this.pl4_2.TabIndex = 126;
            this.pl4_2.ValueMember = "Value";
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.groupBox2);
            this.tabPage4.Controls.Add(this.groupBox1);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(572, 443);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "item";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label29);
            this.groupBox2.Controls.Add(this.label30);
            this.groupBox2.Controls.Add(this.label31);
            this.groupBox2.Controls.Add(this.label32);
            this.groupBox2.Controls.Add(this.it_48);
            this.groupBox2.Controls.Add(this.it_47);
            this.groupBox2.Controls.Add(this.it_46);
            this.groupBox2.Controls.Add(this.it_45);
            this.groupBox2.Controls.Add(this.it_44);
            this.groupBox2.Controls.Add(this.it_43);
            this.groupBox2.Controls.Add(this.it_42);
            this.groupBox2.Controls.Add(this.it_41);
            this.groupBox2.Controls.Add(this.it_38);
            this.groupBox2.Controls.Add(this.it_37);
            this.groupBox2.Controls.Add(this.it_36);
            this.groupBox2.Controls.Add(this.it_35);
            this.groupBox2.Controls.Add(this.it_34);
            this.groupBox2.Controls.Add(this.it_33);
            this.groupBox2.Controls.Add(this.it_32);
            this.groupBox2.Controls.Add(this.it_31);
            this.groupBox2.Location = new System.Drawing.Point(3, 134);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(560, 127);
            this.groupBox2.TabIndex = 88;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Dowsing";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(15, 101);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(39, 13);
            this.label29.TabIndex = 98;
            this.label29.Text = "(25 %):";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(15, 74);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(39, 13);
            this.label30.TabIndex = 97;
            this.label30.Text = "(10 %):";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(21, 47);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(33, 13);
            this.label31.TabIndex = 96;
            this.label31.Text = "(4 %):";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(21, 22);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(33, 13);
            this.label32.TabIndex = 95;
            this.label32.Text = "(1 %):";
            // 
            // it_48
            // 
            this.it_48.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.it_48.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.it_48.DropDownWidth = 150;
            this.it_48.FormattingEnabled = true;
            this.it_48.Location = new System.Drawing.Point(435, 100);
            this.it_48.Name = "it_48";
            this.it_48.Size = new System.Drawing.Size(119, 21);
            this.it_48.TabIndex = 94;
            // 
            // it_47
            // 
            this.it_47.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.it_47.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.it_47.DropDownWidth = 150;
            this.it_47.FormattingEnabled = true;
            this.it_47.Location = new System.Drawing.Point(310, 100);
            this.it_47.Name = "it_47";
            this.it_47.Size = new System.Drawing.Size(119, 21);
            this.it_47.TabIndex = 93;
            // 
            // it_46
            // 
            this.it_46.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.it_46.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.it_46.DropDownWidth = 150;
            this.it_46.FormattingEnabled = true;
            this.it_46.Location = new System.Drawing.Point(185, 100);
            this.it_46.Name = "it_46";
            this.it_46.Size = new System.Drawing.Size(119, 21);
            this.it_46.TabIndex = 92;
            // 
            // it_45
            // 
            this.it_45.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.it_45.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.it_45.DropDownWidth = 150;
            this.it_45.FormattingEnabled = true;
            this.it_45.Location = new System.Drawing.Point(60, 100);
            this.it_45.Name = "it_45";
            this.it_45.Size = new System.Drawing.Size(119, 21);
            this.it_45.TabIndex = 91;
            // 
            // it_44
            // 
            this.it_44.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.it_44.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.it_44.DropDownWidth = 150;
            this.it_44.FormattingEnabled = true;
            this.it_44.Location = new System.Drawing.Point(435, 73);
            this.it_44.Name = "it_44";
            this.it_44.Size = new System.Drawing.Size(119, 21);
            this.it_44.TabIndex = 90;
            // 
            // it_43
            // 
            this.it_43.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.it_43.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.it_43.DropDownWidth = 150;
            this.it_43.FormattingEnabled = true;
            this.it_43.Location = new System.Drawing.Point(310, 73);
            this.it_43.Name = "it_43";
            this.it_43.Size = new System.Drawing.Size(119, 21);
            this.it_43.TabIndex = 89;
            // 
            // it_42
            // 
            this.it_42.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.it_42.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.it_42.DropDownWidth = 150;
            this.it_42.FormattingEnabled = true;
            this.it_42.Location = new System.Drawing.Point(185, 73);
            this.it_42.Name = "it_42";
            this.it_42.Size = new System.Drawing.Size(119, 21);
            this.it_42.TabIndex = 88;
            // 
            // it_41
            // 
            this.it_41.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.it_41.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.it_41.DropDownWidth = 150;
            this.it_41.FormattingEnabled = true;
            this.it_41.Location = new System.Drawing.Point(60, 73);
            this.it_41.Name = "it_41";
            this.it_41.Size = new System.Drawing.Size(119, 21);
            this.it_41.TabIndex = 87;
            // 
            // it_38
            // 
            this.it_38.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.it_38.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.it_38.DropDownWidth = 150;
            this.it_38.FormattingEnabled = true;
            this.it_38.Location = new System.Drawing.Point(435, 46);
            this.it_38.Name = "it_38";
            this.it_38.Size = new System.Drawing.Size(119, 21);
            this.it_38.TabIndex = 86;
            // 
            // it_37
            // 
            this.it_37.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.it_37.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.it_37.DropDownWidth = 150;
            this.it_37.FormattingEnabled = true;
            this.it_37.Location = new System.Drawing.Point(310, 46);
            this.it_37.Name = "it_37";
            this.it_37.Size = new System.Drawing.Size(119, 21);
            this.it_37.TabIndex = 85;
            // 
            // it_36
            // 
            this.it_36.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.it_36.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.it_36.DropDownWidth = 150;
            this.it_36.FormattingEnabled = true;
            this.it_36.Location = new System.Drawing.Point(185, 46);
            this.it_36.Name = "it_36";
            this.it_36.Size = new System.Drawing.Size(119, 21);
            this.it_36.TabIndex = 84;
            // 
            // it_35
            // 
            this.it_35.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.it_35.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.it_35.DropDownWidth = 150;
            this.it_35.FormattingEnabled = true;
            this.it_35.Location = new System.Drawing.Point(60, 46);
            this.it_35.Name = "it_35";
            this.it_35.Size = new System.Drawing.Size(119, 21);
            this.it_35.TabIndex = 83;
            // 
            // it_34
            // 
            this.it_34.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.it_34.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.it_34.DropDownWidth = 150;
            this.it_34.FormattingEnabled = true;
            this.it_34.Location = new System.Drawing.Point(435, 19);
            this.it_34.Name = "it_34";
            this.it_34.Size = new System.Drawing.Size(119, 21);
            this.it_34.TabIndex = 82;
            // 
            // it_33
            // 
            this.it_33.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.it_33.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.it_33.DropDownWidth = 150;
            this.it_33.FormattingEnabled = true;
            this.it_33.Location = new System.Drawing.Point(310, 19);
            this.it_33.Name = "it_33";
            this.it_33.Size = new System.Drawing.Size(119, 21);
            this.it_33.TabIndex = 81;
            // 
            // it_32
            // 
            this.it_32.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.it_32.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.it_32.DropDownWidth = 150;
            this.it_32.FormattingEnabled = true;
            this.it_32.Location = new System.Drawing.Point(185, 19);
            this.it_32.Name = "it_32";
            this.it_32.Size = new System.Drawing.Size(119, 21);
            this.it_32.TabIndex = 80;
            // 
            // it_31
            // 
            this.it_31.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.it_31.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.it_31.DropDownWidth = 150;
            this.it_31.FormattingEnabled = true;
            this.it_31.Location = new System.Drawing.Point(60, 19);
            this.it_31.Name = "it_31";
            this.it_31.Size = new System.Drawing.Size(119, 21);
            this.it_31.TabIndex = 79;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.it_14);
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.Controls.Add(this.it_11);
            this.groupBox1.Controls.Add(this.label18);
            this.groupBox1.Controls.Add(this.it_12);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Controls.Add(this.it_13);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.it_15);
            this.groupBox1.Controls.Add(this.it_28);
            this.groupBox1.Controls.Add(this.it_16);
            this.groupBox1.Controls.Add(this.it_27);
            this.groupBox1.Controls.Add(this.it_17);
            this.groupBox1.Controls.Add(this.it_26);
            this.groupBox1.Controls.Add(this.it_18);
            this.groupBox1.Controls.Add(this.it_25);
            this.groupBox1.Controls.Add(this.it_21);
            this.groupBox1.Controls.Add(this.it_24);
            this.groupBox1.Controls.Add(this.it_22);
            this.groupBox1.Controls.Add(this.it_23);
            this.groupBox1.Location = new System.Drawing.Point(3, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(560, 129);
            this.groupBox1.TabIndex = 87;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Item";
            // 
            // it_14
            // 
            this.it_14.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.it_14.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.it_14.DropDownWidth = 150;
            this.it_14.FormattingEnabled = true;
            this.it_14.Location = new System.Drawing.Point(435, 19);
            this.it_14.Name = "it_14";
            this.it_14.Size = new System.Drawing.Size(119, 21);
            this.it_14.TabIndex = 70;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(15, 101);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(39, 13);
            this.label19.TabIndex = 86;
            this.label19.Text = "(25 %):";
            // 
            // it_11
            // 
            this.it_11.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.it_11.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.it_11.DropDownWidth = 150;
            this.it_11.FormattingEnabled = true;
            this.it_11.Location = new System.Drawing.Point(60, 19);
            this.it_11.Name = "it_11";
            this.it_11.Size = new System.Drawing.Size(119, 21);
            this.it_11.TabIndex = 67;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(15, 74);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(39, 13);
            this.label18.TabIndex = 85;
            this.label18.Text = "(10 %):";
            // 
            // it_12
            // 
            this.it_12.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.it_12.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.it_12.DropDownWidth = 150;
            this.it_12.FormattingEnabled = true;
            this.it_12.Location = new System.Drawing.Point(185, 19);
            this.it_12.Name = "it_12";
            this.it_12.Size = new System.Drawing.Size(119, 21);
            this.it_12.TabIndex = 68;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(21, 47);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(33, 13);
            this.label17.TabIndex = 84;
            this.label17.Text = "(4 %):";
            // 
            // it_13
            // 
            this.it_13.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.it_13.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.it_13.DropDownWidth = 150;
            this.it_13.FormattingEnabled = true;
            this.it_13.Location = new System.Drawing.Point(310, 19);
            this.it_13.Name = "it_13";
            this.it_13.Size = new System.Drawing.Size(119, 21);
            this.it_13.TabIndex = 69;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(21, 22);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(33, 13);
            this.label16.TabIndex = 83;
            this.label16.Text = "(1 %):";
            // 
            // it_15
            // 
            this.it_15.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.it_15.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.it_15.DropDownWidth = 150;
            this.it_15.FormattingEnabled = true;
            this.it_15.Location = new System.Drawing.Point(60, 44);
            this.it_15.Name = "it_15";
            this.it_15.Size = new System.Drawing.Size(119, 21);
            this.it_15.TabIndex = 71;
            // 
            // it_28
            // 
            this.it_28.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.it_28.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.it_28.DropDownWidth = 150;
            this.it_28.FormattingEnabled = true;
            this.it_28.Location = new System.Drawing.Point(435, 98);
            this.it_28.Name = "it_28";
            this.it_28.Size = new System.Drawing.Size(119, 21);
            this.it_28.TabIndex = 82;
            // 
            // it_16
            // 
            this.it_16.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.it_16.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.it_16.DropDownWidth = 150;
            this.it_16.FormattingEnabled = true;
            this.it_16.Location = new System.Drawing.Point(185, 44);
            this.it_16.Name = "it_16";
            this.it_16.Size = new System.Drawing.Size(119, 21);
            this.it_16.TabIndex = 72;
            // 
            // it_27
            // 
            this.it_27.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.it_27.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.it_27.DropDownWidth = 150;
            this.it_27.FormattingEnabled = true;
            this.it_27.Location = new System.Drawing.Point(310, 98);
            this.it_27.Name = "it_27";
            this.it_27.Size = new System.Drawing.Size(119, 21);
            this.it_27.TabIndex = 81;
            // 
            // it_17
            // 
            this.it_17.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.it_17.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.it_17.DropDownWidth = 150;
            this.it_17.FormattingEnabled = true;
            this.it_17.Location = new System.Drawing.Point(310, 44);
            this.it_17.Name = "it_17";
            this.it_17.Size = new System.Drawing.Size(119, 21);
            this.it_17.TabIndex = 73;
            // 
            // it_26
            // 
            this.it_26.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.it_26.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.it_26.DropDownWidth = 150;
            this.it_26.FormattingEnabled = true;
            this.it_26.Location = new System.Drawing.Point(185, 98);
            this.it_26.Name = "it_26";
            this.it_26.Size = new System.Drawing.Size(119, 21);
            this.it_26.TabIndex = 80;
            // 
            // it_18
            // 
            this.it_18.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.it_18.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.it_18.DropDownWidth = 150;
            this.it_18.FormattingEnabled = true;
            this.it_18.Location = new System.Drawing.Point(435, 44);
            this.it_18.Name = "it_18";
            this.it_18.Size = new System.Drawing.Size(119, 21);
            this.it_18.TabIndex = 74;
            // 
            // it_25
            // 
            this.it_25.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.it_25.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.it_25.DropDownWidth = 150;
            this.it_25.FormattingEnabled = true;
            this.it_25.Location = new System.Drawing.Point(60, 98);
            this.it_25.Name = "it_25";
            this.it_25.Size = new System.Drawing.Size(119, 21);
            this.it_25.TabIndex = 79;
            // 
            // it_21
            // 
            this.it_21.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.it_21.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.it_21.DropDownWidth = 150;
            this.it_21.FormattingEnabled = true;
            this.it_21.Location = new System.Drawing.Point(60, 71);
            this.it_21.Name = "it_21";
            this.it_21.Size = new System.Drawing.Size(119, 21);
            this.it_21.TabIndex = 75;
            // 
            // it_24
            // 
            this.it_24.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.it_24.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.it_24.DropDownWidth = 150;
            this.it_24.FormattingEnabled = true;
            this.it_24.Location = new System.Drawing.Point(435, 71);
            this.it_24.Name = "it_24";
            this.it_24.Size = new System.Drawing.Size(119, 21);
            this.it_24.TabIndex = 78;
            // 
            // it_22
            // 
            this.it_22.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.it_22.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.it_22.DropDownWidth = 150;
            this.it_22.FormattingEnabled = true;
            this.it_22.Location = new System.Drawing.Point(185, 71);
            this.it_22.Name = "it_22";
            this.it_22.Size = new System.Drawing.Size(119, 21);
            this.it_22.TabIndex = 76;
            // 
            // it_23
            // 
            this.it_23.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.it_23.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.it_23.DropDownWidth = 150;
            this.it_23.FormattingEnabled = true;
            this.it_23.Location = new System.Drawing.Point(310, 71);
            this.it_23.Name = "it_23";
            this.it_23.Size = new System.Drawing.Size(119, 21);
            this.it_23.TabIndex = 77;
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.groupBox12);
            this.tabPage5.Controls.Add(this.groupBox6);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(572, 443);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "More";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.label28);
            this.groupBox6.Controls.Add(this.label24);
            this.groupBox6.Location = new System.Drawing.Point(7, 3);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(559, 77);
            this.groupBox6.TabIndex = 58;
            this.groupBox6.TabStop = false;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(6, 16);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(44, 13);
            this.label28.TabIndex = 57;
            this.label28.Text = "Offset : ";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(6, 34);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(36, 13);
            this.label24.TabIndex = 55;
            this.label24.Text = "Size : ";
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // id_name
            // 
            this.id_name.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.id_name.DisplayMember = "Name";
            this.id_name.Enabled = false;
            this.id_name.FormattingEnabled = true;
            this.id_name.Location = new System.Drawing.Point(10, 3);
            this.id_name.Name = "id_name";
            this.id_name.Size = new System.Drawing.Size(351, 21);
            this.id_name.TabIndex = 11;
            this.toolTip1.SetToolTip(this.id_name, "Every Pokemon / item table list changed, please click save button for your\r\nchang" +
        "es will save into ram. if you want save to narc file, you must click save, save " +
        "narc button will active.\r\n");
            this.id_name.ValueMember = "Value";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(482, 12);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(79, 13);
            this.label15.TabIndex = 53;
            this.label15.Text = "BW2 : a/2/7/3";
            // 
            // save
            // 
            this.save.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.save.Enabled = false;
            this.save.Location = new System.Drawing.Point(0, 1);
            this.save.Name = "save";
            this.save.Size = new System.Drawing.Size(112, 23);
            this.save.TabIndex = 54;
            this.save.Text = "Save";
            this.toolTip1.SetToolTip(this.save, "You must click this button for save your changes.");
            this.save.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(168, 7);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(25, 23);
            this.button3.TabIndex = 56;
            this.button3.Text = "?";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // splitContainer1
            // 
            this.splitContainer1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.splitContainer1.Location = new System.Drawing.Point(82, 38);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.id_name);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.save);
            this.splitContainer1.Size = new System.Drawing.Size(481, 26);
            this.splitContainer1.SplitterDistance = 363;
            this.splitContainer1.TabIndex = 57;
            // 
            // toolTip1
            // 
            this.toolTip1.IsBalloon = true;
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Location = new System.Drawing.Point(563, 12);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(19, 13);
            this.linkLabel1.TabIndex = 58;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "(?)";
            this.toolTip1.SetToolTip(this.linkLabel1, resources.GetString("linkLabel1.ToolTip"));
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(9, 19);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(91, 17);
            this.checkBox1.TabIndex = 59;
            this.checkBox1.Text = "Hidden tooltip";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(9, 42);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(73, 17);
            this.checkBox2.TabIndex = 60;
            this.checkBox2.Text = "? Editable";
            this.checkBox2.UseVisualStyleBackColor = true;
            this.checkBox2.CheckedChanged += new System.EventHandler(this.checkBox2_CheckedChanged);
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.checkBox2);
            this.groupBox12.Controls.Add(this.checkBox1);
            this.groupBox12.Location = new System.Drawing.Point(7, 86);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(559, 352);
            this.groupBox12.TabIndex = 59;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "Setting";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(589, 542);
            this.Controls.Add(this.linkLabel1);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.id_list);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "A-Hidden Grotto Editor -" + ProductVersion;
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_pl3_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_pl3_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_pl3_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_pl3_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.unk3_6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.unk3_5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.unk3_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.unk3_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.unk3_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.unk3_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fr3_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fr3_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fr3_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fr3_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mn3_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mn3_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mn3_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mn3_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mx3_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mx3_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mx3_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mx3_1)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_pl2_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_pl2_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_pl2_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_pl2_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.unk2_6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.unk2_5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.unk2_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.unk2_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.unk2_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.unk2_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fr2_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fr2_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fr2_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fr2_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mn2_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mn2_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mn2_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mn2_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mx2_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mx2_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mx2_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mx2_1)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_pl1_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_pl1_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_pl1_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_pl1_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.unk1_6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.unk1_5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.unk1_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.unk1_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.unk1_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.unk1_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fr1_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fr1_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fr1_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fr1_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mn1_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mn1_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mn1_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mn1_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mx1_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mx1_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mx1_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mx1_1)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.groupBox11.ResumeLayout(false);
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_pl6_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_pl6_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_pl6_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_pl6_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.unk6_6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.unk6_5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.unk6_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.unk6_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.unk6_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.unk6_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fr6_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fr6_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fr6_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fr6_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mn6_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mn6_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mn6_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mn6_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mx6_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mx6_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mx6_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mx6_1)).EndInit();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_pl5_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_pl5_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_pl5_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_pl5_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.unk5_6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.unk5_5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.unk5_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.unk5_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.unk5_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.unk5_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fr5_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fr5_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fr5_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fr5_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mn5_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mn5_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mn5_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mn5_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mx5_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mx5_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mx5_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mx5_1)).EndInit();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_pl4_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_pl4_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_pl4_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_pl4_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.unk4_6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.unk4_5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.unk4_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.unk4_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.unk4_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.unk4_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fr4_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fr4_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fr4_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fr4_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mn4_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mn4_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mn4_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mn4_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mx4_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mx4_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mx4_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mx4_1)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.ResumeLayout(false);
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox id_list;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.ComboBox id_name;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button save;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.ComboBox it_28;
        private System.Windows.Forms.ComboBox it_27;
        private System.Windows.Forms.ComboBox it_26;
        private System.Windows.Forms.ComboBox it_25;
        private System.Windows.Forms.ComboBox it_24;
        private System.Windows.Forms.ComboBox it_23;
        private System.Windows.Forms.ComboBox it_22;
        private System.Windows.Forms.ComboBox it_21;
        private System.Windows.Forms.ComboBox it_18;
        private System.Windows.Forms.ComboBox it_17;
        private System.Windows.Forms.ComboBox it_16;
        private System.Windows.Forms.ComboBox it_15;
        private System.Windows.Forms.ComboBox it_14;
        private System.Windows.Forms.ComboBox it_13;
        private System.Windows.Forms.ComboBox it_12;
        private System.Windows.Forms.ComboBox it_11;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.NumericUpDown unk2_6;
        private System.Windows.Forms.NumericUpDown unk2_5;
        private System.Windows.Forms.NumericUpDown unk2_4;
        private System.Windows.Forms.NumericUpDown unk2_3;
        private System.Windows.Forms.NumericUpDown unk2_2;
        private System.Windows.Forms.NumericUpDown unk2_1;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.NumericUpDown fr2_4;
        private System.Windows.Forms.NumericUpDown fr2_3;
        private System.Windows.Forms.NumericUpDown fr2_2;
        private System.Windows.Forms.NumericUpDown fr2_1;
        private System.Windows.Forms.NumericUpDown mn2_4;
        private System.Windows.Forms.NumericUpDown mn2_3;
        private System.Windows.Forms.NumericUpDown mn2_2;
        private System.Windows.Forms.NumericUpDown mn2_1;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.NumericUpDown mx2_4;
        private System.Windows.Forms.NumericUpDown mx2_3;
        private System.Windows.Forms.NumericUpDown mx2_2;
        private System.Windows.Forms.NumericUpDown mx2_1;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.ComboBox pl2_4;
        private System.Windows.Forms.ComboBox pl2_1;
        private System.Windows.Forms.ComboBox pl2_3;
        private System.Windows.Forms.ComboBox pl2_2;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.NumericUpDown unk1_6;
        private System.Windows.Forms.NumericUpDown unk1_5;
        private System.Windows.Forms.NumericUpDown unk1_4;
        private System.Windows.Forms.NumericUpDown unk1_3;
        private System.Windows.Forms.NumericUpDown unk1_2;
        private System.Windows.Forms.NumericUpDown unk1_1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.NumericUpDown fr1_4;
        private System.Windows.Forms.NumericUpDown fr1_3;
        private System.Windows.Forms.NumericUpDown fr1_2;
        private System.Windows.Forms.NumericUpDown fr1_1;
        private System.Windows.Forms.NumericUpDown mn1_4;
        private System.Windows.Forms.NumericUpDown mn1_3;
        private System.Windows.Forms.NumericUpDown mn1_2;
        private System.Windows.Forms.NumericUpDown mn1_1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown mx1_4;
        private System.Windows.Forms.NumericUpDown mx1_3;
        private System.Windows.Forms.NumericUpDown mx1_2;
        private System.Windows.Forms.NumericUpDown mx1_1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox pl1_4;
        private System.Windows.Forms.ComboBox pl1_1;
        private System.Windows.Forms.ComboBox pl1_3;
        private System.Windows.Forms.ComboBox pl1_2;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.ComboBox it_48;
        private System.Windows.Forms.ComboBox it_47;
        private System.Windows.Forms.ComboBox it_46;
        private System.Windows.Forms.ComboBox it_45;
        private System.Windows.Forms.ComboBox it_44;
        private System.Windows.Forms.ComboBox it_43;
        private System.Windows.Forms.ComboBox it_42;
        private System.Windows.Forms.ComboBox it_41;
        private System.Windows.Forms.ComboBox it_38;
        private System.Windows.Forms.ComboBox it_37;
        private System.Windows.Forms.ComboBox it_36;
        private System.Windows.Forms.ComboBox it_35;
        private System.Windows.Forms.ComboBox it_34;
        private System.Windows.Forms.ComboBox it_33;
        private System.Windows.Forms.ComboBox it_32;
        private System.Windows.Forms.ComboBox it_31;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.NumericUpDown unk3_6;
        private System.Windows.Forms.NumericUpDown unk3_5;
        private System.Windows.Forms.NumericUpDown unk3_4;
        private System.Windows.Forms.NumericUpDown unk3_3;
        private System.Windows.Forms.NumericUpDown unk3_2;
        private System.Windows.Forms.NumericUpDown unk3_1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.NumericUpDown fr3_4;
        private System.Windows.Forms.NumericUpDown fr3_3;
        private System.Windows.Forms.NumericUpDown fr3_2;
        private System.Windows.Forms.NumericUpDown fr3_1;
        private System.Windows.Forms.NumericUpDown mn3_4;
        private System.Windows.Forms.NumericUpDown mn3_3;
        private System.Windows.Forms.NumericUpDown mn3_2;
        private System.Windows.Forms.NumericUpDown mn3_1;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.NumericUpDown mx3_4;
        private System.Windows.Forms.NumericUpDown mx3_3;
        private System.Windows.Forms.NumericUpDown mx3_2;
        private System.Windows.Forms.NumericUpDown mx3_1;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.ComboBox pl3_4;
        private System.Windows.Forms.ComboBox pl3_1;
        private System.Windows.Forms.ComboBox pl3_3;
        private System.Windows.Forms.ComboBox pl3_2;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.PictureBox pbx_pl1_1;
        private System.Windows.Forms.PictureBox pbx_pl1_4;
        private System.Windows.Forms.PictureBox pbx_pl1_3;
        private System.Windows.Forms.PictureBox pbx_pl1_2;
        private System.Windows.Forms.PictureBox pbx_pl3_4;
        private System.Windows.Forms.PictureBox pbx_pl3_3;
        private System.Windows.Forms.PictureBox pbx_pl3_2;
        private System.Windows.Forms.PictureBox pbx_pl3_1;
        private System.Windows.Forms.PictureBox pbx_pl2_4;
        private System.Windows.Forms.PictureBox pbx_pl2_3;
        private System.Windows.Forms.PictureBox pbx_pl2_2;
        private System.Windows.Forms.PictureBox pbx_pl2_1;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.PictureBox pbx_pl4_4;
        private System.Windows.Forms.PictureBox pbx_pl4_3;
        private System.Windows.Forms.PictureBox pbx_pl4_2;
        private System.Windows.Forms.PictureBox pbx_pl4_1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.NumericUpDown unk4_6;
        private System.Windows.Forms.NumericUpDown unk4_5;
        private System.Windows.Forms.NumericUpDown unk4_4;
        private System.Windows.Forms.NumericUpDown unk4_3;
        private System.Windows.Forms.NumericUpDown unk4_2;
        private System.Windows.Forms.NumericUpDown unk4_1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.NumericUpDown fr4_4;
        private System.Windows.Forms.NumericUpDown fr4_3;
        private System.Windows.Forms.NumericUpDown fr4_2;
        private System.Windows.Forms.NumericUpDown fr4_1;
        private System.Windows.Forms.NumericUpDown mn4_4;
        private System.Windows.Forms.NumericUpDown mn4_3;
        private System.Windows.Forms.NumericUpDown mn4_2;
        private System.Windows.Forms.NumericUpDown mn4_1;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.NumericUpDown mx4_4;
        private System.Windows.Forms.NumericUpDown mx4_3;
        private System.Windows.Forms.NumericUpDown mx4_2;
        private System.Windows.Forms.NumericUpDown mx4_1;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.ComboBox pl4_4;
        private System.Windows.Forms.ComboBox pl4_1;
        private System.Windows.Forms.ComboBox pl4_3;
        private System.Windows.Forms.ComboBox pl4_2;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.PictureBox pbx_pl6_4;
        private System.Windows.Forms.PictureBox pbx_pl6_3;
        private System.Windows.Forms.PictureBox pbx_pl6_2;
        private System.Windows.Forms.PictureBox pbx_pl6_1;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.NumericUpDown unk6_6;
        private System.Windows.Forms.NumericUpDown unk6_5;
        private System.Windows.Forms.NumericUpDown unk6_4;
        private System.Windows.Forms.NumericUpDown unk6_3;
        private System.Windows.Forms.NumericUpDown unk6_2;
        private System.Windows.Forms.NumericUpDown unk6_1;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.NumericUpDown fr6_4;
        private System.Windows.Forms.NumericUpDown fr6_3;
        private System.Windows.Forms.NumericUpDown fr6_2;
        private System.Windows.Forms.NumericUpDown fr6_1;
        private System.Windows.Forms.NumericUpDown mn6_4;
        private System.Windows.Forms.NumericUpDown mn6_3;
        private System.Windows.Forms.NumericUpDown mn6_2;
        private System.Windows.Forms.NumericUpDown mn6_1;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.NumericUpDown mx6_4;
        private System.Windows.Forms.NumericUpDown mx6_3;
        private System.Windows.Forms.NumericUpDown mx6_2;
        private System.Windows.Forms.NumericUpDown mx6_1;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.ComboBox pl6_4;
        private System.Windows.Forms.ComboBox pl6_1;
        private System.Windows.Forms.ComboBox pl6_3;
        private System.Windows.Forms.ComboBox pl6_2;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.PictureBox pbx_pl5_4;
        private System.Windows.Forms.PictureBox pbx_pl5_3;
        private System.Windows.Forms.PictureBox pbx_pl5_2;
        private System.Windows.Forms.PictureBox pbx_pl5_1;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.NumericUpDown unk5_6;
        private System.Windows.Forms.NumericUpDown unk5_5;
        private System.Windows.Forms.NumericUpDown unk5_4;
        private System.Windows.Forms.NumericUpDown unk5_3;
        private System.Windows.Forms.NumericUpDown unk5_2;
        private System.Windows.Forms.NumericUpDown unk5_1;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.NumericUpDown fr5_4;
        private System.Windows.Forms.NumericUpDown fr5_3;
        private System.Windows.Forms.NumericUpDown fr5_2;
        private System.Windows.Forms.NumericUpDown fr5_1;
        private System.Windows.Forms.NumericUpDown mn5_4;
        private System.Windows.Forms.NumericUpDown mn5_3;
        private System.Windows.Forms.NumericUpDown mn5_2;
        private System.Windows.Forms.NumericUpDown mn5_1;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.NumericUpDown mx5_4;
        private System.Windows.Forms.NumericUpDown mx5_3;
        private System.Windows.Forms.NumericUpDown mx5_2;
        private System.Windows.Forms.NumericUpDown mx5_1;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.ComboBox pl5_4;
        private System.Windows.Forms.ComboBox pl5_1;
        private System.Windows.Forms.ComboBox pl5_3;
        private System.Windows.Forms.ComboBox pl5_2;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.GroupBox groupBox12;
    }
}

