﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.IO;
using System.Windows.Forms;
using System.Collections;
using AHGE;

namespace Percobaan
{
    public partial class Form1 : Form
    {
        public MemoryStream NarcFile = new MemoryStream();
        public MemoryStream MapFile = new MemoryStream();
        public uint FileCount;
        public uint FileOffset;
        public uint FileSize;
        public uint FATOffset;
        public uint Pokemon1;
        public uint Pokemon2;
        public uint Pokemon3;
        public uint Pokemon4;
        public uint Max1;
        public uint Max2;
        public uint Max3;
        public uint Max4;
        public uint Min1;
        public uint Min2;
        public uint Min3;
        public uint Min4;
        public uint frate1;
        public uint frate2;
        public uint frate3;
        public uint frate4;
        public uint unkw1;
        public uint unkw2;
        public uint unkw3;
        public uint unkw4;
        public uint unkw5;
        public uint unkw6;
        public uint item11;
        public int a;
        public string b;
        public Form1()
        {
            InitializeComponent();
            string locations_bw2; 

            locations_bw2 = @"data\icons_pkm\";

            //load list
            pl1_1.DataSource = (ArrayList)Program.PokeList.GetArrayList().Clone();
            pl1_2.DataSource = (ArrayList)Program.PokeList.GetArrayList().Clone();
            pl1_3.DataSource = (ArrayList)Program.PokeList.GetArrayList().Clone();
            pl1_4.DataSource = (ArrayList)Program.PokeList.GetArrayList().Clone();
            pl2_4.DataSource = (ArrayList)Program.PokeList.GetArrayList().Clone();
            pl2_1.DataSource = (ArrayList)Program.PokeList.GetArrayList().Clone();
            pl2_3.DataSource = (ArrayList)Program.PokeList.GetArrayList().Clone();
            pl2_2.DataSource = (ArrayList)Program.PokeList.GetArrayList().Clone();
            pl3_4.DataSource = (ArrayList)Program.PokeList.GetArrayList().Clone();
            pl3_1.DataSource = (ArrayList)Program.PokeList.GetArrayList().Clone();
            pl3_3.DataSource = (ArrayList)Program.PokeList.GetArrayList().Clone();
            pl3_2.DataSource = (ArrayList)Program.PokeList.GetArrayList().Clone();
            pl4_1.DataSource = (ArrayList)Program.PokeList.GetArrayList().Clone();
            pl4_3.DataSource = (ArrayList)Program.PokeList.GetArrayList().Clone();
            pl4_2.DataSource = (ArrayList)Program.PokeList.GetArrayList().Clone();
            pl4_4.DataSource = (ArrayList)Program.PokeList.GetArrayList().Clone();
            pl5_1.DataSource = (ArrayList)Program.PokeList.GetArrayList().Clone();
            pl5_3.DataSource = (ArrayList)Program.PokeList.GetArrayList().Clone();
            pl5_2.DataSource = (ArrayList)Program.PokeList.GetArrayList().Clone();
            pl5_4.DataSource = (ArrayList)Program.PokeList.GetArrayList().Clone();
            pl6_1.DataSource = (ArrayList)Program.PokeList.GetArrayList().Clone();
            pl6_3.DataSource = (ArrayList)Program.PokeList.GetArrayList().Clone();
            pl6_2.DataSource = (ArrayList)Program.PokeList.GetArrayList().Clone();
            pl6_4.DataSource = (ArrayList)Program.PokeList.GetArrayList().Clone();
            it_11.DataSource = (ArrayList)Program.ItemList.GetArrayList().Clone();
            it_12.DataSource = (ArrayList)Program.ItemList.GetArrayList().Clone();
            it_13.DataSource = (ArrayList)Program.ItemList.GetArrayList().Clone();
            it_14.DataSource = (ArrayList)Program.ItemList.GetArrayList().Clone();
            it_18.DataSource = (ArrayList)Program.ItemList.GetArrayList().Clone();
            it_17.DataSource = (ArrayList)Program.ItemList.GetArrayList().Clone();
            it_16.DataSource = (ArrayList)Program.ItemList.GetArrayList().Clone();
            it_15.DataSource = (ArrayList)Program.ItemList.GetArrayList().Clone();
            it_28.DataSource = (ArrayList)Program.ItemList.GetArrayList().Clone();
            it_27.DataSource = (ArrayList)Program.ItemList.GetArrayList().Clone();
            it_26.DataSource = (ArrayList)Program.ItemList.GetArrayList().Clone();
            it_25.DataSource = (ArrayList)Program.ItemList.GetArrayList().Clone();
            it_24.DataSource = (ArrayList)Program.ItemList.GetArrayList().Clone();
            it_23.DataSource = (ArrayList)Program.ItemList.GetArrayList().Clone();
            it_22.DataSource = (ArrayList)Program.ItemList.GetArrayList().Clone();
            it_21.DataSource = (ArrayList)Program.ItemList.GetArrayList().Clone();
            it_38.DataSource = (ArrayList)Program.ItemList.GetArrayList().Clone();
            it_37.DataSource = (ArrayList)Program.ItemList.GetArrayList().Clone();
            it_36.DataSource = (ArrayList)Program.ItemList.GetArrayList().Clone();
            it_35.DataSource = (ArrayList)Program.ItemList.GetArrayList().Clone();
            it_34.DataSource = (ArrayList)Program.ItemList.GetArrayList().Clone();
            it_33.DataSource = (ArrayList)Program.ItemList.GetArrayList().Clone();
            it_32.DataSource = (ArrayList)Program.ItemList.GetArrayList().Clone();
            it_31.DataSource = (ArrayList)Program.ItemList.GetArrayList().Clone();
            it_41.DataSource = (ArrayList)Program.ItemList.GetArrayList().Clone();
            it_42.DataSource = (ArrayList)Program.ItemList.GetArrayList().Clone();
            it_43.DataSource = (ArrayList)Program.ItemList.GetArrayList().Clone();
            it_44.DataSource = (ArrayList)Program.ItemList.GetArrayList().Clone();
            it_45.DataSource = (ArrayList)Program.ItemList.GetArrayList().Clone();
            it_46.DataSource = (ArrayList)Program.ItemList.GetArrayList().Clone();
            it_47.DataSource = (ArrayList)Program.ItemList.GetArrayList().Clone();
            it_48.DataSource = (ArrayList)Program.ItemList.GetArrayList().Clone();
            id_name.DataSource = (ArrayList)Program.loc1List.GetArrayList().Clone();

            this.pl1_1.SelectedIndexChanged += new EventHandler(this.pl1_1_SelectedValueChanged);
            this.pl1_2.SelectedIndexChanged += new EventHandler(this.pl1_2_SelectedValueChanged);
            this.pl1_3.SelectedIndexChanged += new EventHandler(this.pl1_3_SelectedValueChanged);
            this.pl1_4.SelectedIndexChanged += new EventHandler(this.pl1_4_SelectedValueChanged);
            this.pl2_1.SelectedIndexChanged += new EventHandler(this.pl2_1_SelectedValueChanged);
            this.pl2_2.SelectedIndexChanged += new EventHandler(this.pl2_2_SelectedValueChanged);
            this.pl2_3.SelectedIndexChanged += new EventHandler(this.pl2_3_SelectedValueChanged);
            this.pl2_4.SelectedIndexChanged += new EventHandler(this.pl2_4_SelectedValueChanged);
            this.pl3_1.SelectedIndexChanged += new EventHandler(this.pl3_1_SelectedValueChanged);
            this.pl3_2.SelectedIndexChanged += new EventHandler(this.pl3_2_SelectedValueChanged);
            this.pl3_3.SelectedIndexChanged += new EventHandler(this.pl3_3_SelectedValueChanged);
            this.pl3_4.SelectedIndexChanged += new EventHandler(this.pl3_4_SelectedValueChanged);
            this.pl4_1.SelectedIndexChanged += new EventHandler(this.pl4_1_SelectedValueChanged);
            this.pl4_2.SelectedIndexChanged += new EventHandler(this.pl4_2_SelectedValueChanged);
            this.pl4_3.SelectedIndexChanged += new EventHandler(this.pl4_3_SelectedValueChanged);
            this.pl4_4.SelectedIndexChanged += new EventHandler(this.pl4_4_SelectedValueChanged);
            this.pl5_1.SelectedIndexChanged += new EventHandler(this.pl5_1_SelectedValueChanged);
            this.pl5_2.SelectedIndexChanged += new EventHandler(this.pl5_2_SelectedValueChanged);
            this.pl5_3.SelectedIndexChanged += new EventHandler(this.pl5_3_SelectedValueChanged);
            this.pl5_4.SelectedIndexChanged += new EventHandler(this.pl5_4_SelectedValueChanged);
            this.pl6_1.SelectedIndexChanged += new EventHandler(this.pl6_1_SelectedValueChanged);
            this.pl6_2.SelectedIndexChanged += new EventHandler(this.pl6_2_SelectedValueChanged);
            this.pl6_3.SelectedIndexChanged += new EventHandler(this.pl6_3_SelectedValueChanged);
            this.pl6_4.SelectedIndexChanged += new EventHandler(this.pl6_4_SelectedValueChanged);

            this.pbx_pl1_1.ImageLocation = StartupPath + locations_bw2 + "_0" + ".png";
            this.pbx_pl1_2.ImageLocation = StartupPath + locations_bw2 + "_0" + ".png";
            this.pbx_pl1_3.ImageLocation = StartupPath + locations_bw2 + "_0" + ".png";
            this.pbx_pl1_4.ImageLocation = StartupPath + locations_bw2 + "_0" + ".png";
            this.pbx_pl2_1.ImageLocation = StartupPath + locations_bw2 + "_0" + ".png";
            this.pbx_pl2_2.ImageLocation = StartupPath + locations_bw2 + "_0" + ".png";
            this.pbx_pl2_3.ImageLocation = StartupPath + locations_bw2 + "_0" + ".png";
            this.pbx_pl2_4.ImageLocation = StartupPath + locations_bw2 + "_0" + ".png";
            this.pbx_pl3_1.ImageLocation = StartupPath + locations_bw2 + "_0" + ".png";
            this.pbx_pl3_2.ImageLocation = StartupPath + locations_bw2 + "_0" + ".png";
            this.pbx_pl3_3.ImageLocation = StartupPath + locations_bw2 + "_0" + ".png";
            this.pbx_pl3_4.ImageLocation = StartupPath + locations_bw2 + "_0" + ".png";

            this.id_name.SelectedIndexChanged += new EventHandler(this.id_name_SelectedIndexChanged);
            this.id_list.SelectedIndexChanged += new EventHandler(this.id_list_SelectedIndexChanged);

            
            this.save.Click += new EventHandler(this.save_Click);

            
            //this.button2.Click += new EventHandler(this.button2_Click); 
        }

        //startup pathnya biar portable
        public static string StartupPath
        {
            get
            {
                string startupPath = Application.StartupPath;
                if (!startupPath.EndsWith(@"\"))
                {
                    startupPath = startupPath + @"\";
                }
                return startupPath;
            }
        }

        //button
        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Title = "Open Narc File";
            dialog.Filter = "Nitro Archive (a/2/7/3) (*.narc)|*.narc|All Files (*.*)|*.*";

            if (dialog.ShowDialog() == DialogResult.OK)
            {
                BinaryReader reader = new BinaryReader(File.OpenRead(dialog.FileName));
                byte[] buffer = new byte[reader.BaseStream.Length];
                reader.BaseStream.Position = 0L;
                this.NarcFile.Position = 0L;
                reader.Read(buffer, 0, (int)reader.BaseStream.Length);
                this.NarcFile.Write(buffer, 0, (int)reader.BaseStream.Length);
                reader.Close();
                this.NarcFile.Position = 0x18L;
                this.FileCount = (uint)(((this.NarcFile.ReadByte() + (this.NarcFile.ReadByte() << 8)) + (this.NarcFile.ReadByte() << 0x10)) + (this.NarcFile.ReadByte() << 0x18));
                this.id_list.Items.Clear();
                for (int i = 0; i < this.FileCount; i++)
                {
                    this.id_list.Items.Add(i.ToString("0"));
                }
                this.FATOffset = (0x1c + (this.FileCount * 8)) + 0x18;

                this.id_list.SelectedIndex = 0;
                this.id_name.SelectedValue = this.id_list.SelectedIndex;
                this.id_list.Enabled = true;
                this.id_name.Enabled = true;
                this.tabControl1.Enabled = true;
                //this.button2.Enabled = true;
                this.save.Enabled = true;
            }
        }

        private void save_Click(object sender, EventArgs e)
        {

            this.MapFile.Position = 0L;
            this.Pokemon1 = (uint)((int)(this.pl1_1.SelectedValue));
            this.Pokemon2 = (uint)((int)(this.pl1_2.SelectedValue));
            this.Pokemon3 = (uint)((int)(this.pl1_3.SelectedValue));
            this.Pokemon4 = (uint)((int)(this.pl1_4.SelectedValue));
            this.Max1 = (uint)this.mx1_1.Value;
            this.Max2 = (uint)this.mx1_2.Value;
            this.Max3 = (uint)this.mx1_3.Value;
            this.Max4 = (uint)this.mx1_4.Value;
            this.Min1 = (uint)this.mn1_1.Value;
            this.Min2 = (uint)this.mn1_2.Value;
            this.Min3 = (uint)this.mn1_3.Value;
            this.Min4 = (uint)this.mn1_4.Value;
            this.frate1 = (uint)this.fr1_1.Value;
            this.frate2 = (uint)this.fr1_2.Value;
            this.frate3 = (uint)this.fr1_3.Value;
            this.frate4 = (uint)this.fr1_4.Value;
            this.unkw1 = (uint)this.unk1_1.Value;
            this.unkw2 = (uint)this.unk1_2.Value;
            this.unkw3 = (uint)this.unk1_3.Value;
            this.unkw4 = (uint)this.unk1_4.Value;
            this.unkw5 = (uint)this.unk1_5.Value;
            this.unkw6 = (uint)this.unk1_6.Value;            
            this.WriteNextEntry();

            //this.MapFile.Position = 0x1AL;
            this.Pokemon1 = (uint)(((int)this.pl2_1.SelectedValue));
            this.Pokemon2 = (uint)(((int)this.pl2_2.SelectedValue));
            this.Pokemon3 = (uint)(((int)this.pl2_3.SelectedValue));
            this.Pokemon4 = (uint)(((int)this.pl2_4.SelectedValue));
            this.Max1 = (uint)this.mx2_1.Value;
            this.Max2 = (uint)this.mx2_2.Value;
            this.Max3 = (uint)this.mx2_3.Value;
            this.Max4 = (uint)this.mx2_4.Value;
            this.Min1 = (uint)this.mn2_1.Value;
            this.Min2 = (uint)this.mn2_2.Value;
            this.Min3 = (uint)this.mn2_3.Value;
            this.Min4 = (uint)this.mn2_4.Value;
            this.frate1 = (uint)this.fr2_1.Value;
            this.frate2 = (uint)this.fr2_2.Value;
            this.frate3 = (uint)this.fr2_3.Value;
            this.frate4 = (uint)this.fr2_4.Value;
            this.unkw1 = (uint)this.unk2_1.Value;
            this.unkw2 = (uint)this.unk2_2.Value;
            this.unkw3 = (uint)this.unk2_3.Value;
            this.unkw4 = (uint)this.unk2_4.Value;
            this.unkw5 = (uint)this.unk2_5.Value;
            this.unkw6 = (uint)this.unk2_6.Value;
            this.WriteNextEntry();

            //this.MapFile.Position = 0x34L;
            this.Pokemon1 = (uint)((int)(this.pl3_1.SelectedValue));
            this.Pokemon2 = (uint)((int)(this.pl3_2.SelectedValue));
            this.Pokemon3 = (uint)((int)(this.pl3_3.SelectedValue));
            this.Pokemon4 = (uint)((int)(this.pl3_4.SelectedValue));
            this.Max1 = (uint)this.mx3_1.Value;
            this.Max2 = (uint)this.mx3_2.Value;
            this.Max3 = (uint)this.mx3_3.Value;
            this.Max4 = (uint)this.mx3_4.Value;
            this.Min1 = (uint)this.mn3_1.Value;
            this.Min2 = (uint)this.mn3_2.Value;
            this.Min3 = (uint)this.mn3_3.Value;
            this.Min4 = (uint)this.mn3_4.Value;
            this.frate1 = (uint)this.fr3_1.Value;
            this.frate2 = (uint)this.fr3_2.Value;
            this.frate3 = (uint)this.fr3_3.Value;
            this.frate4 = (uint)this.fr3_4.Value;
            this.unkw1 = (uint)this.unk3_1.Value;
            this.unkw2 = (uint)this.unk3_2.Value;
            this.unkw3 = (uint)this.unk3_3.Value;
            this.unkw4 = (uint)this.unk3_4.Value;
            this.unkw5 = (uint)this.unk3_5.Value;
            this.unkw6 = (uint)this.unk3_6.Value;
            this.WriteNextEntry();

            //this.MapFile.Position = 0x34L;
            this.Pokemon1 = (uint)((int)(this.pl4_1.SelectedValue));
            this.Pokemon2 = (uint)((int)(this.pl4_2.SelectedValue));
            this.Pokemon3 = (uint)((int)(this.pl4_3.SelectedValue));
            this.Pokemon4 = (uint)((int)(this.pl4_4.SelectedValue));
            this.Max1 = (uint)this.mx4_1.Value;
            this.Max2 = (uint)this.mx4_2.Value;
            this.Max3 = (uint)this.mx4_3.Value;
            this.Max4 = (uint)this.mx4_4.Value;
            this.Min1 = (uint)this.mn4_1.Value;
            this.Min2 = (uint)this.mn4_2.Value;
            this.Min3 = (uint)this.mn4_3.Value;
            this.Min4 = (uint)this.mn4_4.Value;
            this.frate1 = (uint)this.fr4_1.Value;
            this.frate2 = (uint)this.fr4_2.Value;
            this.frate3 = (uint)this.fr4_3.Value;
            this.frate4 = (uint)this.fr4_4.Value;
            this.unkw1 = (uint)this.unk4_1.Value;
            this.unkw2 = (uint)this.unk4_2.Value;
            this.unkw3 = (uint)this.unk4_3.Value;
            this.unkw4 = (uint)this.unk4_4.Value;
            this.unkw5 = (uint)this.unk4_5.Value;
            this.unkw6 = (uint)this.unk4_6.Value;
            this.WriteNextEntry();

            this.Pokemon1 = (uint)((int)(this.pl5_1.SelectedValue));
            this.Pokemon2 = (uint)((int)(this.pl5_2.SelectedValue));
            this.Pokemon3 = (uint)((int)(this.pl5_3.SelectedValue));
            this.Pokemon4 = (uint)((int)(this.pl5_4.SelectedValue));
            this.Max1 = (uint)this.mx5_1.Value;
            this.Max2 = (uint)this.mx5_2.Value;
            this.Max3 = (uint)this.mx5_3.Value;
            this.Max4 = (uint)this.mx5_4.Value;
            this.Min1 = (uint)this.mn5_1.Value;
            this.Min2 = (uint)this.mn5_2.Value;
            this.Min3 = (uint)this.mn5_3.Value;
            this.Min4 = (uint)this.mn5_4.Value;
            this.frate1 = (uint)this.fr5_1.Value;
            this.frate2 = (uint)this.fr5_2.Value;
            this.frate3 = (uint)this.fr5_3.Value;
            this.frate4 = (uint)this.fr5_4.Value;
            this.unkw1 = (uint)this.unk5_1.Value;
            this.unkw2 = (uint)this.unk5_2.Value;
            this.unkw3 = (uint)this.unk5_3.Value;
            this.unkw4 = (uint)this.unk5_4.Value;
            this.unkw5 = (uint)this.unk5_5.Value;
            this.unkw6 = (uint)this.unk5_6.Value;
            this.WriteNextEntry();

            this.Pokemon1 = (uint)((int)(this.pl6_1.SelectedValue));
            this.Pokemon2 = (uint)((int)(this.pl6_2.SelectedValue));
            this.Pokemon3 = (uint)((int)(this.pl6_3.SelectedValue));
            this.Pokemon4 = (uint)((int)(this.pl6_4.SelectedValue));
            this.Max1 = (uint)this.mx6_1.Value;
            this.Max2 = (uint)this.mx6_2.Value;
            this.Max3 = (uint)this.mx6_3.Value;
            this.Max4 = (uint)this.mx6_4.Value;
            this.Min1 = (uint)this.mn6_1.Value;
            this.Min2 = (uint)this.mn6_2.Value;
            this.Min3 = (uint)this.mn6_3.Value;
            this.Min4 = (uint)this.mn6_4.Value;
            this.frate1 = (uint)this.fr6_1.Value;
            this.frate2 = (uint)this.fr6_2.Value;
            this.frate3 = (uint)this.fr6_3.Value;
            this.frate4 = (uint)this.fr6_4.Value;
            this.unkw1 = (uint)this.unk6_1.Value;
            this.unkw2 = (uint)this.unk6_2.Value;
            this.unkw3 = (uint)this.unk6_3.Value;
            this.unkw4 = (uint)this.unk6_4.Value;
            this.unkw5 = (uint)this.unk6_5.Value;
            this.unkw6 = (uint)this.unk6_6.Value;
            this.WriteNextEntry();

            this.MapFile.Position = 0x9cL;
            this.item11 = (uint)(this.it_11.SelectedIndex);
            this.WriteNextEntry2();
            this.item11 = (uint)(this.it_12.SelectedIndex);
            this.WriteNextEntry2();
            this.item11 = (uint)(this.it_13.SelectedIndex);
            this.WriteNextEntry2();
            this.item11 = (uint)(this.it_14.SelectedIndex);
            this.WriteNextEntry2();
            this.item11 = (uint)(this.it_15.SelectedIndex);
            this.WriteNextEntry2();
            this.item11 = (uint)(this.it_16.SelectedIndex);
            this.WriteNextEntry2();
            this.item11 = (uint)(this.it_17.SelectedIndex);
            this.WriteNextEntry2();
            this.item11 = (uint)(this.it_18.SelectedIndex);
            this.WriteNextEntry2();
            this.item11 = (uint)(this.it_21.SelectedIndex);
            this.WriteNextEntry2();
            this.item11 = (uint)(this.it_22.SelectedIndex);
            this.WriteNextEntry2();
            this.item11 = (uint)(this.it_23.SelectedIndex);
            this.WriteNextEntry2();
            this.item11 = (uint)(this.it_24.SelectedIndex);
            this.WriteNextEntry2();
            this.item11 = (uint)(this.it_25.SelectedIndex);
            this.WriteNextEntry2();
            this.item11 = (uint)(this.it_26.SelectedIndex);
            this.WriteNextEntry2();
            this.item11 = (uint)(this.it_27.SelectedIndex);
            this.WriteNextEntry2();
            this.item11 = (uint)(this.it_28.SelectedIndex);
            this.WriteNextEntry2();
            this.item11 = (uint)(this.it_31.SelectedIndex);
            this.WriteNextEntry2();
            this.item11 = (uint)(this.it_32.SelectedIndex);
            this.WriteNextEntry2();
            this.item11 = (uint)(this.it_33.SelectedIndex);
            this.WriteNextEntry2();
            this.item11 = (uint)(this.it_34.SelectedIndex);
            this.WriteNextEntry2();
            this.item11 = (uint)(this.it_35.SelectedIndex);
            this.WriteNextEntry2();
            this.item11 = (uint)(this.it_36.SelectedIndex);
            this.WriteNextEntry2();
            this.item11 = (uint)(this.it_37.SelectedIndex);
            this.WriteNextEntry2();
            this.item11 = (uint)(this.it_38.SelectedIndex);
            this.WriteNextEntry2();
            this.item11 = (uint)(this.it_41.SelectedIndex);
            this.WriteNextEntry2();
            this.item11 = (uint)(this.it_42.SelectedIndex);
            this.WriteNextEntry2();
            this.item11 = (uint)(this.it_43.SelectedIndex);
            this.WriteNextEntry2();
            this.item11 = (uint)(this.it_44.SelectedIndex);
            this.WriteNextEntry2();
            this.item11 = (uint)(this.it_45.SelectedIndex);
            this.WriteNextEntry2();
            this.item11 = (uint)(this.it_46.SelectedIndex);
            this.WriteNextEntry2();
            this.item11 = (uint)(this.it_47.SelectedIndex);
            this.WriteNextEntry2();
            this.item11 = (uint)(this.it_48.SelectedIndex);
            this.WriteNextEntry2();

            this.NarcFile.Position = this.FileOffset + this.FATOffset;
            this.NarcFile.Write(this.MapFile.ToArray(), 0, (int)this.FileSize);
            this.button2.Enabled = true;
        }

        //fungsi nulis dan baca
        private void ReadData()
        {
            this.MapFile.Position = 0L;

            this.ReadNextEntry();
            this.pl1_1.SelectedValue = (int)this.Pokemon1;
            this.pl1_2.SelectedValue = (int)this.Pokemon2;
            this.pl1_3.SelectedValue = (int)this.Pokemon3;
            this.pl1_4.SelectedValue = (int)this.Pokemon4;
            this.mx1_1.Value = this.Max1;
            this.mx1_2.Value = this.Max2;
            this.mx1_3.Value = this.Max3;
            this.mx1_4.Value = this.Max4;
            this.mn1_1.Value = this.Min1;
            this.mn1_2.Value = this.Min2;
            this.mn1_3.Value = this.Min3;
            this.mn1_4.Value = this.Min4;
            this.fr1_1.Value = this.frate1;
            this.fr1_2.Value = this.frate2;
            this.fr1_3.Value = this.frate3;
            this.fr1_4.Value = this.frate4;
            this.unk1_1.Value = this.unkw1;
            this.unk1_2.Value = this.unkw2;
            this.unk1_3.Value = this.unkw3;
            this.unk1_4.Value = this.unkw4;
            this.unk1_5.Value = this.unkw5;
            this.unk1_6.Value = this.unkw6;

            this.ReadNextEntry();
            this.pl2_1.SelectedValue = (int)this.Pokemon1;
            this.pl2_2.SelectedValue = (int)this.Pokemon2;
            this.pl2_3.SelectedValue = (int)this.Pokemon3;
            this.pl2_4.SelectedValue = (int)this.Pokemon4;
            this.mx2_1.Value = this.Max1;
            this.mx2_2.Value = this.Max2;
            this.mx2_3.Value = this.Max3;
            this.mx2_4.Value = this.Max4;
            this.mn2_1.Value = this.Min1;
            this.mn2_2.Value = this.Min2;
            this.mn2_3.Value = this.Min3;
            this.mn2_4.Value = this.Min4;
            this.fr2_1.Value = this.frate1;
            this.fr2_2.Value = this.frate2;
            this.fr2_3.Value = this.frate3;
            this.fr2_4.Value = this.frate4;
            this.unk2_1.Value = this.unkw1;
            this.unk2_2.Value = this.unkw2;
            this.unk2_3.Value = this.unkw3;
            this.unk2_4.Value = this.unkw4;
            this.unk2_5.Value = this.unkw5;
            this.unk2_6.Value = this.unkw6;

            this.ReadNextEntry();
            this.pl3_1.SelectedValue = (int)this.Pokemon1;
            this.pl3_2.SelectedValue = (int)this.Pokemon2;
            this.pl3_3.SelectedValue = (int)this.Pokemon3;
            this.pl3_4.SelectedValue = (int)this.Pokemon4;
            this.mx3_1.Value = this.Max1;
            this.mx3_2.Value = this.Max2;
            this.mx3_3.Value = this.Max3;
            this.mx3_4.Value = this.Max4;
            this.mn3_1.Value = this.Min1;
            this.mn3_2.Value = this.Min2;
            this.mn3_3.Value = this.Min3;
            this.mn3_4.Value = this.Min4;
            this.fr3_1.Value = this.frate1;
            this.fr3_2.Value = this.frate2;
            this.fr3_3.Value = this.frate3;
            this.fr3_4.Value = this.frate4;
            this.unk3_1.Value = this.unkw1;
            this.unk3_2.Value = this.unkw2;
            this.unk3_3.Value = this.unkw3;
            this.unk3_4.Value = this.unkw4;
            this.unk3_5.Value = this.unkw5;
            this.unk3_6.Value = this.unkw6;

            this.ReadNextEntry();
            this.pl4_1.SelectedValue = (int)this.Pokemon1;
            this.pl4_2.SelectedValue = (int)this.Pokemon2;
            this.pl4_3.SelectedValue = (int)this.Pokemon3;
            this.pl4_4.SelectedValue = (int)this.Pokemon4;
            this.mx4_1.Value = this.Max1;
            this.mx4_2.Value = this.Max2;
            this.mx4_3.Value = this.Max3;
            this.mx4_4.Value = this.Max4;
            this.mn4_1.Value = this.Min1;
            this.mn4_2.Value = this.Min2;
            this.mn4_3.Value = this.Min3;
            this.mn4_4.Value = this.Min4;
            this.fr4_1.Value = this.frate1;
            this.fr4_2.Value = this.frate2;
            this.fr4_3.Value = this.frate3;
            this.fr4_4.Value = this.frate4;
            this.unk4_1.Value = this.unkw1;
            this.unk4_2.Value = this.unkw2;
            this.unk4_3.Value = this.unkw3;
            this.unk4_4.Value = this.unkw4;
            this.unk4_5.Value = this.unkw5;
            this.unk4_6.Value = this.unkw6;

            this.ReadNextEntry();
            this.pl5_1.SelectedValue = (int)this.Pokemon1;
            this.pl5_2.SelectedValue = (int)this.Pokemon2;
            this.pl5_3.SelectedValue = (int)this.Pokemon3;
            this.pl5_4.SelectedValue = (int)this.Pokemon4;
            this.mx5_1.Value = this.Max1;
            this.mx5_2.Value = this.Max2;
            this.mx5_3.Value = this.Max3;
            this.mx5_4.Value = this.Max4;
            this.mn5_1.Value = this.Min1;
            this.mn5_2.Value = this.Min2;
            this.mn5_3.Value = this.Min3;
            this.mn5_4.Value = this.Min4;
            this.fr5_1.Value = this.frate1;
            this.fr5_2.Value = this.frate2;
            this.fr5_3.Value = this.frate3;
            this.fr5_4.Value = this.frate4;
            this.unk5_1.Value = this.unkw1;
            this.unk5_2.Value = this.unkw2;
            this.unk5_3.Value = this.unkw3;
            this.unk5_4.Value = this.unkw4;
            this.unk5_5.Value = this.unkw5;
            this.unk5_6.Value = this.unkw6;

            this.ReadNextEntry();
            this.pl6_1.SelectedValue = (int)this.Pokemon1;
            this.pl6_2.SelectedValue = (int)this.Pokemon2;
            this.pl6_3.SelectedValue = (int)this.Pokemon3;
            this.pl6_4.SelectedValue = (int)this.Pokemon4;
            this.mx6_1.Value = this.Max1;
            this.mx6_2.Value = this.Max2;
            this.mx6_3.Value = this.Max3;
            this.mx6_4.Value = this.Max4;
            this.mn6_1.Value = this.Min1;
            this.mn6_2.Value = this.Min2;
            this.mn6_3.Value = this.Min3;
            this.mn6_4.Value = this.Min4;
            this.fr6_1.Value = this.frate1;
            this.fr6_2.Value = this.frate2;
            this.fr6_3.Value = this.frate3;
            this.fr6_4.Value = this.frate4;
            this.unk6_1.Value = this.unkw1;
            this.unk6_2.Value = this.unkw2;
            this.unk6_3.Value = this.unkw3;
            this.unk6_4.Value = this.unkw4;
            this.unk6_5.Value = this.unkw5;
            this.unk6_6.Value = this.unkw6;

            this.MapFile.Position = 0x9cL;
            this.ReadNextEntry2();
            this.it_11.SelectedIndex = (int)this.item11;
            this.ReadNextEntry2();
            this.it_12.SelectedIndex = (int)this.item11;
            this.ReadNextEntry2();
            this.it_13.SelectedIndex = (int)this.item11;
            this.ReadNextEntry2();
            this.it_14.SelectedIndex = (int)this.item11;
            this.ReadNextEntry2();
            this.it_15.SelectedIndex = (int)this.item11;
            this.ReadNextEntry2();
            this.it_16.SelectedIndex = (int)this.item11;
            this.ReadNextEntry2();
            this.it_17.SelectedIndex = (int)this.item11;
            this.ReadNextEntry2();
            this.it_18.SelectedIndex = (int)this.item11;
            this.ReadNextEntry2();
            this.it_21.SelectedIndex = (int)this.item11;
            this.ReadNextEntry2();
            this.it_22.SelectedIndex = (int)this.item11;
            this.ReadNextEntry2();
            this.it_23.SelectedIndex = (int)this.item11;
            this.ReadNextEntry2();
            this.it_24.SelectedIndex = (int)this.item11;
            this.ReadNextEntry2();
            this.it_25.SelectedIndex = (int)this.item11;
            this.ReadNextEntry2();
            this.it_26.SelectedIndex = (int)this.item11;
            this.ReadNextEntry2();
            this.it_27.SelectedIndex = (int)this.item11;
            this.ReadNextEntry2();
            this.it_28.SelectedIndex = (int)this.item11;
            this.ReadNextEntry2();
            this.it_31.SelectedIndex = (int)this.item11;
            this.ReadNextEntry2();
            this.it_32.SelectedIndex = (int)this.item11;
            this.ReadNextEntry2();
            this.it_33.SelectedIndex = (int)this.item11;
            this.ReadNextEntry2();
            this.it_34.SelectedIndex = (int)this.item11;
            this.ReadNextEntry2();
            this.it_35.SelectedIndex = (int)this.item11;
            this.ReadNextEntry2();
            this.it_36.SelectedIndex = (int)this.item11;
            this.ReadNextEntry2();
            this.it_37.SelectedIndex = (int)this.item11;
            this.ReadNextEntry2();
            this.it_38.SelectedIndex = (int)this.item11;
            this.ReadNextEntry2();
            this.it_41.SelectedIndex = (int)this.item11;
            this.ReadNextEntry2();
            this.it_42.SelectedIndex = (int)this.item11;
            this.ReadNextEntry2();
            this.it_43.SelectedIndex = (int)this.item11;
            this.ReadNextEntry2();
            this.it_44.SelectedIndex = (int)this.item11;
            this.ReadNextEntry2();
            this.it_45.SelectedIndex = (int)this.item11;
            this.ReadNextEntry2();
            this.it_46.SelectedIndex = (int)this.item11;
            this.ReadNextEntry2();
            this.it_47.SelectedIndex = (int)this.item11;
            this.ReadNextEntry2();
            this.it_48.SelectedIndex = (int)this.item11;
        }

        private void ReadNextEntry()
        {
            this.Pokemon1 = (uint)(this.MapFile.ReadByte() + (this.MapFile.ReadByte() * 0x100));
            this.Pokemon2 = (uint)(this.MapFile.ReadByte() + (this.MapFile.ReadByte() * 0x100));
            this.Pokemon3 = (uint)(this.MapFile.ReadByte() + (this.MapFile.ReadByte() * 0x100));
            this.Pokemon4 = (uint)(this.MapFile.ReadByte() + (this.MapFile.ReadByte() * 0x100));
            
            this.Max1 = 0;
            this.Max2 = 0;
            this.Max3 = 0;
            this.Max4 = 0;
            this.Min1 = 0;
            this.Min2 = 0;
            this.Min3 = 0;
            this.Min4 = 0;
            this.frate1 = 0;
            this.frate2 = 0;
            this.frate3 = 0;
            this.frate4 = 0;
            this.unkw1 = 0;
            this.unkw2 = 0;
            this.unkw3 = 0;
            this.unkw4 = 0;
            this.unkw5 = 0;
            this.unkw6 = 0;
            
            while (this.Pokemon1 > 0x800)
            {
                this.Pokemon1 -= 0x800;
            }
            while (this.Pokemon2 > 0x800)
            {
                this.Pokemon2 -= 0x800;
            }
            while (this.Pokemon3 > 0x800)
            {
                this.Pokemon3 -= 0x800;
            }
            while (this.Pokemon4 > 0x800)
            {
                this.Pokemon4 -= 0x800;
            }
            
            this.Max1 = (uint)this.MapFile.ReadByte();
            this.Max2 = (uint)this.MapFile.ReadByte();
            this.Max3 = (uint)this.MapFile.ReadByte();
            this.Max4 = (uint)this.MapFile.ReadByte();
            this.Min1 = (uint)this.MapFile.ReadByte();
            this.Min2 = (uint)this.MapFile.ReadByte();
            this.Min3 = (uint)this.MapFile.ReadByte();
            this.Min4 = (uint)this.MapFile.ReadByte();
            this.frate1 = (uint)this.MapFile.ReadByte();
            this.frate2 = (uint)this.MapFile.ReadByte();
            this.frate3 = (uint)this.MapFile.ReadByte();
            this.frate4 = (uint)this.MapFile.ReadByte();
            this.unkw1 = (uint)this.MapFile.ReadByte();
            this.unkw2 = (uint)this.MapFile.ReadByte();
            this.unkw3 = (uint)this.MapFile.ReadByte();
            this.unkw4 = (uint)this.MapFile.ReadByte();
            this.unkw5 = (uint)this.MapFile.ReadByte();
            this.unkw6 = (uint)this.MapFile.ReadByte();
        }

        private void ReadNextEntry2()
        {
            this.item11 = (uint)(this.MapFile.ReadByte() + (this.MapFile.ReadByte() * 0x100));

            while (this.item11 > 0x800)
            {
                this.item11 -= 0x800;
            }
        }
    
        private void WriteNextEntry()
        {
            this.MapFile.WriteByte((byte)(this.Pokemon1 - ((this.Pokemon1 >> 8) << 8)));
            this.MapFile.WriteByte((byte)(this.Pokemon1 >> 8));
            this.MapFile.WriteByte((byte)(this.Pokemon2 - ((this.Pokemon2 >> 8) << 8)));
            this.MapFile.WriteByte((byte)(this.Pokemon2 >> 8));
            this.MapFile.WriteByte((byte)(this.Pokemon3 - ((this.Pokemon3 >> 8) << 8)));
            this.MapFile.WriteByte((byte)(this.Pokemon3 >> 8));
            this.MapFile.WriteByte((byte)(this.Pokemon4 - ((this.Pokemon4 >> 8) << 8)));
            this.MapFile.WriteByte((byte)(this.Pokemon4 >> 8));
            
            this.MapFile.WriteByte((byte)this.Max1);
            this.MapFile.WriteByte((byte)this.Max2);
            this.MapFile.WriteByte((byte)this.Max3);
            this.MapFile.WriteByte((byte)this.Max4);

            this.MapFile.WriteByte((byte)this.Min1);
            this.MapFile.WriteByte((byte)this.Min2);
            this.MapFile.WriteByte((byte)this.Min3);
            this.MapFile.WriteByte((byte)this.Min4);

            this.MapFile.WriteByte((byte)this.frate1);
            this.MapFile.WriteByte((byte)this.frate2);
            this.MapFile.WriteByte((byte)this.frate3);
            this.MapFile.WriteByte((byte)this.frate4);

            this.MapFile.WriteByte((byte)this.unkw1);
            this.MapFile.WriteByte((byte)this.unkw2);
            this.MapFile.WriteByte((byte)this.unkw3);
            this.MapFile.WriteByte((byte)this.unkw4);
            this.MapFile.WriteByte((byte)this.unkw5);
            this.MapFile.WriteByte((byte)this.unkw6);
        }

        private void WriteNextEntry2()
        {
            this.MapFile.WriteByte((byte)(this.item11 - ((this.item11 >> 8) << 8)));
            this.MapFile.WriteByte((byte)(this.item11 >> 8));  
        }

        //button nyimpen narc
        private void button2_Click(object sender, EventArgs e)
        {
            SaveFileDialog dialog = new SaveFileDialog();
            dialog.Title = "Save Narc File";
            dialog.Filter = "Nitro Archive (*.narc)|*.narc|All Files (*.*)|*.*";
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                File.WriteAllBytes(dialog.FileName, this.NarcFile.ToArray());
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form2 form = new Form2();

            form.ShowDialog();
        }

        //pengecekan perubahan id
        public void id_name_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (this.id_name.SelectedIndex < 0)
            {
                this.id_name.SelectedIndex = 0;
            }
            else if (this.id_name.SelectedIndex >= this.id_name.Items.Count)
            {
                this.id_name.SelectedIndex = this.id_name.Items.Count - 1;
            }
            this.id_list.SelectedIndex = (int)this.id_name.SelectedValue;
            this.button2.Enabled = false;

        }

        public void id_list_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (this.id_list.SelectedIndex < 0)
            {
                this.id_list.SelectedIndex = 0;
            }
            else if (this.id_list.SelectedIndex >= this.id_list.Items.Count)
            {
                this.id_list.SelectedIndex = this.id_list.Items.Count - 1;
            }
            this.id_name.SelectedValue = this.id_list.SelectedIndex;

            this.NarcFile.Position = 0x1c + (this.id_list.SelectedIndex * 8);
            this.FileOffset = (uint)(((this.NarcFile.ReadByte() + (this.NarcFile.ReadByte() * 0x100)) + (this.NarcFile.ReadByte() * 0x10000)) + (this.NarcFile.ReadByte() * 0x1000000));
            this.FileSize = ((uint)(((this.NarcFile.ReadByte() + (this.NarcFile.ReadByte() * 0x100)) + (this.NarcFile.ReadByte() * 0x10000)) + (this.NarcFile.ReadByte() * 0x1000000))) - this.FileOffset;
            this.MapFile = new MemoryStream();
            this.MapFile.Position = 0L;
            this.MapFile.Write(this.NarcFile.ToArray(), (int)(this.FileOffset + this.FATOffset), (int)this.FileSize);

            if (this.FileSize == 0xdc)
            {
                this.MapFile.Position = 0L;
                this.ReadData();
            }
            label24.Text = "Size : " + FileSize;

            String dos;
            dos = (0xD4 + FileOffset).ToString("X");
            label28.Text = "Offset : 0x" + (dos);
            this.button2.Enabled = false;
        }

        private void read_value_image()
        {  /*
            a = (int)unk6_1.Value;

            if (a == 0)
            {
                b = (int)this.pl6_1.SelectedValue + ".png";
            }
            else
            {
                b = (int)this.pl6_1.SelectedValue + "-" + a + ".png";
            }*/

            b = (int)this.pl6_1.SelectedValue + ".png";
        }

        public void pl1_1_SelectedValueChanged(object sender, EventArgs e)
        {
            this.pbx_pl1_1.ImageLocation = StartupPath + @"data\icons_pkm\" + (int)this.pl1_1.SelectedValue + ".png";
        }

        public void pl1_2_SelectedValueChanged(object sender, EventArgs e)
        {
            this.pbx_pl1_2.ImageLocation = StartupPath + @"data\icons_pkm\" + (int)this.pl1_2.SelectedValue + ".png";
        }

        public void pl1_3_SelectedValueChanged(object sender, EventArgs e)
        {
            this.pbx_pl1_3.ImageLocation = StartupPath + @"data\icons_pkm\" + (int)this.pl1_3.SelectedValue + ".png";
        }

        public void pl1_4_SelectedValueChanged(object sender, EventArgs e)
        {
            this.pbx_pl1_4.ImageLocation = StartupPath + @"data\icons_pkm\" + (int)this.pl1_4.SelectedValue + ".png";
        }

        public void pl2_1_SelectedValueChanged(object sender, EventArgs e)
        {
            this.pbx_pl2_1.ImageLocation = StartupPath + @"data\icons_pkm\" + (int)this.pl2_1.SelectedValue + ".png";
        }

        public void pl2_2_SelectedValueChanged(object sender, EventArgs e)
        {
            this.pbx_pl2_2.ImageLocation = StartupPath + @"data\icons_pkm\" + (int)this.pl2_2.SelectedValue + ".png";
        }

        public void pl2_3_SelectedValueChanged(object sender, EventArgs e)
        {
            this.pbx_pl2_3.ImageLocation = StartupPath + @"data\icons_pkm\" + (int)this.pl2_3.SelectedValue + ".png";
        }

        public void pl2_4_SelectedValueChanged(object sender, EventArgs e)
        {
            this.pbx_pl2_4.ImageLocation = StartupPath + @"data\icons_pkm\" + (int)this.pl2_4.SelectedValue + ".png";
        }

        public void pl3_1_SelectedValueChanged(object sender, EventArgs e)
        {
            this.pbx_pl3_1.ImageLocation = StartupPath + @"data\icons_pkm\" + (int)this.pl3_1.SelectedValue + ".png";
        }

        public void pl3_2_SelectedValueChanged(object sender, EventArgs e)
        {
            this.pbx_pl3_2.ImageLocation = StartupPath + @"data\icons_pkm\" + (int)this.pl3_2.SelectedValue + ".png";
        }

        public void pl3_3_SelectedValueChanged(object sender, EventArgs e)
        {
            this.pbx_pl3_3.ImageLocation = StartupPath + @"data\icons_pkm\" + (int)this.pl3_3.SelectedValue + ".png";
        }

        public void pl3_4_SelectedValueChanged(object sender, EventArgs e)
        {
            this.pbx_pl3_4.ImageLocation = StartupPath + @"data\icons_pkm\" + (int)this.pl3_4.SelectedValue + ".png";
        }

        public void pl4_1_SelectedValueChanged(object sender, EventArgs e)
        {
            this.pbx_pl4_1.ImageLocation = StartupPath + @"data\icons_pkm\" + (int)this.pl4_1.SelectedValue + ".png";
        }

        public void pl4_2_SelectedValueChanged(object sender, EventArgs e)
        {
            this.pbx_pl4_2.ImageLocation = StartupPath + @"data\icons_pkm\" + (int)this.pl4_2.SelectedValue + ".png";
        }

        public void pl4_3_SelectedValueChanged(object sender, EventArgs e)
        {
            this.pbx_pl4_3.ImageLocation = StartupPath + @"data\icons_pkm\" + (int)this.pl4_3.SelectedValue + ".png";
        }

        public void pl4_4_SelectedValueChanged(object sender, EventArgs e)
        {
            this.pbx_pl4_4.ImageLocation = StartupPath + @"data\icons_pkm\" + (int)this.pl4_4.SelectedValue + ".png";
        }

        public void pl5_1_SelectedValueChanged(object sender, EventArgs e)
        {
            this.pbx_pl5_1.ImageLocation = StartupPath + @"data\icons_pkm\" + (int)this.pl5_1.SelectedValue + ".png";
        }

        public void pl5_2_SelectedValueChanged(object sender, EventArgs e)
        {
            this.pbx_pl5_2.ImageLocation = StartupPath + @"data\icons_pkm\" + (int)this.pl5_2.SelectedValue + ".png";
        }

        public void pl5_3_SelectedValueChanged(object sender, EventArgs e)
        {
            this.pbx_pl5_3.ImageLocation = StartupPath + @"data\icons_pkm\" + (int)this.pl5_3.SelectedValue + ".png";
        }

        public void pl5_4_SelectedValueChanged(object sender, EventArgs e)
        {
            this.pbx_pl5_4.ImageLocation = StartupPath + @"data\icons_pkm\" + (int)this.pl5_4.SelectedValue + ".png";
        }

        public void pl6_1_SelectedValueChanged(object sender, EventArgs e)
        {
            read_value_image();
            this.pbx_pl6_1.ImageLocation = StartupPath + @"data\icons_pkm\" + b;

            //this.pbx_pl6_1.ImageLocation = StartupPath + @"data\icons_pkm\" + (int)this.pl6_1.SelectedValue + ".png";
        }

        public void pl6_2_SelectedValueChanged(object sender, EventArgs e)
        {
            this.pbx_pl6_2.ImageLocation = StartupPath + @"data\icons_pkm\" + (int)this.pl6_2.SelectedValue + ".png";
        }

        public void pl6_3_SelectedValueChanged(object sender, EventArgs e)
        {
            this.pbx_pl6_3.ImageLocation = StartupPath + @"data\icons_pkm\" + (int)this.pl6_3.SelectedValue + ".png";
        }

        public void pl6_4_SelectedValueChanged(object sender, EventArgs e)
        {
            this.pbx_pl6_4.ImageLocation = StartupPath + @"data\icons_pkm\" + (int)this.pl6_4.SelectedValue + ".png";
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                toolTip1.Active = false;
            }
            else
            {
                toolTip1.Active = true;
            }
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked)
            {
                unk1_5.Enabled = true;
                unk1_6.Enabled = true;
                unk2_5.Enabled = true;
                unk2_6.Enabled = true;
                unk3_5.Enabled = true;
                unk3_6.Enabled = true;
                unk4_5.Enabled = true;
                unk4_6.Enabled = true;
                unk5_5.Enabled = true;
                unk5_6.Enabled = true;
                unk6_5.Enabled = true;
                unk6_6.Enabled = true;
            }
            else
            {
                unk1_5.Enabled = false;
                unk1_6.Enabled = false;
                unk2_5.Enabled = false;
                unk2_6.Enabled = false;
                unk3_5.Enabled = false;
                unk3_6.Enabled = false;
                unk4_5.Enabled = false;
                unk4_6.Enabled = false;
                unk5_5.Enabled = false;
                unk5_6.Enabled = false;
                unk6_5.Enabled = false;
                unk6_6.Enabled = false;
            }
        }

    }
}
