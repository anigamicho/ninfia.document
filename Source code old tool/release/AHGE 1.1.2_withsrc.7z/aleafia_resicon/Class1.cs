﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace aleafia_resicon
{
    public class Class1
    {
    }
}
