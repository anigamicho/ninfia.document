This builds was used part of my new core is leafia 2 alpha 3, this not really done and i not used all part of leafia 2 (aleafia / a.leafia_xxx) on this build, so it will be changed on future is on structure and coding.

For now is used simple language system on AHGE, i think i will change it on leafia 2 or next if is using leafia 2.

is just make exe is more smaller than it without dll files.