
ANDI POKEMON MOVESET 1.0 (AMSE)

    This tools for editing a moveset on pokemon BW and BW2 games
    With easy without editing manually via HEX. But this tool 
    Not able direct to added new slot move. If you want added
    new slot moves, you must added it manually via hex editor.
    before that you must excrating container into small pieces,
    after that you can added new slot moves, after that you can
    re-pack them, and you can load that narc file via this tool.
    AMSE able load modified slot moves, since AMSE is looking
    offset so is not worried if moveset in every pokemon is 
    different.

 Created by :
   Andibad-ra (pp.org members)

 version :
   - 1.1.0.0 beta 1 (32 bit)

 using :
   - VS 2012 C#
   - net.framework 4 (recommend using win 7 and 8)
   - Nini.dll for ini config library

 narc :
   - a/0/1/8 (BW and BW2) , please don't open moveset data from
                            older pkm games, maybe it will error.
                            

 Features :
   - edit moveset pokemon.
   - small, easy, proffesional GUI interface.
   - is still can't added new slot but is able to change moveset.
   - search function on the list.
   - source tab, for checking and for copying hex value.
   - this tools for now limit maximum moveset slot to 25 moves
     (0 - 25, is was include FFFF FF FF slot).

 History :

 [1.1b1] :
    - added : config.ini, but is incomplete (is not my 1st priority)
    - added : tooltip, just testing, maybe next build will be used.
    - buggy : added new move slot is buggy, so is disabled
    - buggy : double click on datagrid, is still buggy so for now
              don't use that.
    - used my newer design template set so it will look ok than 
      before.

 [1.0]
    - first release.

sorry my tools is incomplete and not all my goal is success 
btw is was work fine
editing pokemon moveset on BW/BW2/BBVW2 successfully. i hope
it will work fine on you too.



2012